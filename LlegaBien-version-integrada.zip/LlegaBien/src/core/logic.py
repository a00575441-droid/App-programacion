"""Lógica de LlegaBien: riesgo de traslado, costo de la rotación y acciones.

Aquí están las funciones F1 a F8 del D3 (MVP Blueprint) y algunas de apoyo.
Las ventanas solo muestran resultados: todos los cálculos se hacen aquí.
"""
import math

# Reglas del equipo (D3) para el semáforo de riesgo
MINUTOS_ALTO = 60
MINUTOS_MEDIO = 30
TRANSBORDOS_ALTO = 2
TRANSBORDOS_MEDIO = 1

# Reglas del equipo (D3) para las alertas
PORCENTAJE_ALERTA = 20     # % de la plantilla que tarda 60 minutos o más
COLONIA_ALERTA = 10        # trabajadores en riesgo alto en una misma colonia

# Explicación de cada nivel, para mostrarla en las ventanas
REGLA_RIESGO = {
    "ALTO": "60 minutos o más, o 2 transbordos o más",
    "MEDIO": "30 minutos o más, o 1 transbordo",
    "BAJO": "menos de 30 minutos y sin transbordos",
}

MEDIOS_EN_VEHICULO = ("Auto", "Moto")   # medios que suman coches a la calle


def promedio(valores: list) -> float:
    """Promedio sin pandas (de la plantilla del profe)."""
    if not valores:
        return 0.0
    acumulado = 0.0
    for valor in valores:
        acumulado += valor
    return acumulado / len(valores)


# ---------- F1 ----------
def clasificar_riesgo(minutos: int, transbordos: int) -> str:
    """F1. Regresa "ALTO", "MEDIO" o "BAJO" según el traslado de un trabajador."""
    if minutos >= MINUTOS_ALTO or transbordos >= TRANSBORDOS_ALTO:
        return "ALTO"
    if minutos >= MINUTOS_MEDIO or transbordos == TRANSBORDOS_MEDIO:
        return "MEDIO"
    return "BAJO"


# ---------- F2 ----------
def resumir_plantilla(trabajadores: list) -> dict:
    """F2. Cuenta trabajadores por nivel de riesgo y el % que tarda 60 min o más."""
    resumen = {"total": len(trabajadores), "ALTO": 0, "MEDIO": 0, "BAJO": 0}
    largos = 0
    for trabajador in trabajadores:
        nivel = clasificar_riesgo(trabajador["minutos"], trabajador["transbordos"])
        resumen[nivel] += 1
        if trabajador["minutos"] >= MINUTOS_ALTO:
            largos += 1
    if resumen["total"] > 0:
        resumen["porcentaje_largos"] = round(largos / resumen["total"] * 100, 1)
    else:
        resumen["porcentaje_largos"] = 0.0      # evita dividir entre cero
    return resumen


# ---------- F3 ----------
def colonias_con_mas_riesgo(trabajadores: list, cuantas: int = 3) -> list:
    """F3. Regresa las colonias con más trabajadores en riesgo ALTO: [(colonia, conteo), ...]."""
    conteo = {}
    for trabajador in trabajadores:
        if clasificar_riesgo(trabajador["minutos"], trabajador["transbordos"]) == "ALTO":
            colonia = trabajador["colonia"]
            conteo[colonia] = conteo.get(colonia, 0) + 1
    # Ordena de mayor a menor conteo; si empatan, por nombre
    ordenadas = sorted(conteo.items(), key=lambda par: (-par[1], par[0]))
    return ordenadas[:cuantas]


# ---------- F4 ----------
def calcular_costo_rotacion(empleados: int, rotacion_mensual: float,
                            costo_por_salida: float, proporcion_traslado: float) -> dict:
    """F4. Costo al año de la rotación y la parte que se debe al traslado.

    rotacion_mensual va en porcentaje (5 = 5 %); proporcion_traslado entre 0 y 1.
    """
    salidas = round(empleados * rotacion_mensual / 100 * 12)
    costo_total = salidas * costo_por_salida
    salidas_traslado = round(salidas * proporcion_traslado)
    costo_traslado = salidas_traslado * costo_por_salida
    return {
        "salidas": salidas,
        "costo_total": costo_total,
        "salidas_traslado": salidas_traslado,
        "costo_traslado": costo_traslado,
    }


# ---------- F5 ----------
def retardos_por_hora(trabajadores: list) -> dict:
    """Promedio de retardos al mes por trabajador en cada hora de entrada."""
    retardos = {}
    personas = {}
    for trabajador in trabajadores:
        hora = trabajador["hora_entrada"]
        retardos[hora] = retardos.get(hora, 0) + trabajador["retardos"]
        personas[hora] = personas.get(hora, 0) + 1
    promedios = {}
    for hora in sorted(retardos):
        promedios[hora] = retardos[hora] / personas[hora]
    return promedios


def hora_con_mas_retardos(trabajadores: list) -> tuple:
    """F5. Regresa (hora crítica, promedio de retardos por trabajador)."""
    promedios = retardos_por_hora(trabajadores)
    hora_critica = "--"
    mayor = 0.0
    for hora, valor in promedios.items():
        if valor > mayor:
            hora_critica = hora
            mayor = valor
    return hora_critica, round(mayor, 2)


# ---------- F6 ----------
def ruta_se_paga(costo_ruta_mensual: float, costo_por_salida: float, salidas_traslado: int) -> tuple:
    """F6. Cuántas renuncias debe evitar una ruta para pagarse y si conviene."""
    renuncias = math.ceil(costo_ruta_mensual * 12 / costo_por_salida)
    conviene = renuncias <= salidas_traslado
    return renuncias, conviene


# ---------- F7 ----------
def generar_alertas(porcentaje_largos: float, colonias: list) -> list:
    """F7. Mensajes de alerta para RH según las reglas del equipo."""
    alertas = []
    if porcentaje_largos > PORCENTAJE_ALERTA:
        alertas.append(f"Más de {PORCENTAJE_ALERTA} % de la plantilla tarda 60 minutos o más")
    for colonia, conteo in colonias:
        if conteo >= COLONIA_ALERTA:
            alertas.append(f"{colonia}: {conteo} trabajadores en riesgo alto, evaluar una ruta")
    return alertas


# ---------- F8 ----------
def validar_trabajador(minutos: str, transbordos: str, retardos: str) -> tuple:
    """F8. Revisa lo que se escribió en el formulario. Regresa (es_valido, mensaje)."""
    try:
        minutos = int(minutos)
        transbordos = int(transbordos)
        retardos = int(retardos)
    except ValueError:
        return False, "Minutos, transbordos y retardos deben ser números enteros"
    if minutos < 0 or transbordos < 0 or retardos < 0:
        return False, "Los números no pueden ser negativos"
    return True, "Datos correctos"


# ---------- Funciones de apoyo ----------
def validar_hora(texto: str) -> bool:
    """Revisa que la hora tenga la forma HH:MM (por ejemplo 07:00)."""
    if len(texto) != 5 or texto[2] != ":":
        return False
    try:
        horas = int(texto[:2])
        minutos = int(texto[3:])
    except ValueError:
        return False
    return 0 <= horas <= 23 and 0 <= minutos <= 59


def mover_hora(hora: str, minutos: int) -> str:
    """Suma (o resta) minutos a una hora HH:MM. Ejemplo: mover_hora("07:00", -30) -> "06:30"."""
    total = int(hora[:2]) * 60 + int(hora[3:]) + minutos
    total = total % (24 * 60)          # si pasa de medianoche, da la vuelta
    return f"{total // 60:02d}:{total % 60:02d}"


def resumir_colonia(trabajadores: list, colonia: str) -> dict:
    """Cuántos trabajadores hay en una colonia, cuántos en riesgo alto y cuántos van en auto o moto."""
    resumen = {"total": 0, "alto": 0, "en_vehiculo": 0}
    for trabajador in trabajadores:
        if trabajador["colonia"] == colonia:
            resumen["total"] += 1
            if clasificar_riesgo(trabajador["minutos"], trabajador["transbordos"]) == "ALTO":
                resumen["alto"] += 1
            if trabajador["medio"] in MEDIOS_EN_VEHICULO:
                resumen["en_vehiculo"] += 1
    return resumen


def salidas_de_colonia(salidas_traslado: int, alto_colonia: int, alto_total: int) -> int:
    """Parte de las salidas por traslado que corresponde a una colonia
    (en proporción a sus trabajadores en riesgo alto)."""
    if alto_total == 0:
        return 0
    return round(salidas_traslado * alto_colonia / alto_total)


def estimar_costo_ruta(trabajadores_en_ruta: int, costo_por_trabajador_anio: float) -> int:
    """Estimado del costo mensual de una ruta, redondeado a cientos de pesos."""
    return int(round(trabajadores_en_ruta * costo_por_trabajador_anio / 12, -2))


def calcular_costo_llegabien(empleados: int, precio_mensual: float, costo_por_salida: float) -> dict:
    """Lo que paga la empresa por LlegaBien y cuántas renuncias debe evitar para pagarse."""
    mensual = empleados * precio_mensual
    anual = mensual * 12
    renuncias = math.ceil(anual / costo_por_salida)
    return {"mensual": mensual, "anual": anual, "renuncias_para_pagarse": renuncias}


def convertir_numero(texto: str) -> float:
    """Convierte lo que escribe el usuario a número. Acepta "47,000", "$47000" o "5 %".
    Si no es un número, lanza ValueError (la ventana lo atrapa con try/except)."""
    limpio = texto.strip().replace(",", "").replace("$", "").replace("%", "")
    return float(limpio)


def plural(cantidad: int, singular: str, plural_: str) -> str:
    """Escribe "1 renuncia" o "3 renuncias"."""
    return f"{cantidad} {singular if cantidad == 1 else plural_}"


def formato_pesos(cantidad: float) -> str:
    """Escribe una cantidad como dinero: 4042000 -> "$4,042,000"."""
    return f"${cantidad:,.0f}"
