"""Lectura y escritura de los archivos CSV de LlegaBien (biblioteca estándar csv)."""
from pathlib import Path
import csv

CARPETA_DATOS = Path(__file__).resolve().parents[2] / "data"
RUTA_EJEMPLO = CARPETA_DATOS / "trabajadores_ejemplo.csv"     # datos ficticios para la demostración
RUTA_USUARIO = CARPETA_DATOS / "trabajadores_usuario.csv"     # los que se registran en la app

COLUMNAS = ["numero", "colonia", "hora_entrada", "medio", "minutos", "transbordos", "retardos"]
COLUMNAS_NUMERICAS = ["minutos", "transbordos", "retardos"]


def cargar_csv(ruta) -> list:
    """Lee un CSV y regresa una lista de diccionarios (de la plantilla del profe)."""
    ruta = Path(ruta)
    with ruta.open("r", encoding="utf-8", newline="") as archivo:
        return list(csv.DictReader(archivo))


def cargar_trabajadores(rutas: list) -> list:
    """Junta los trabajadores de varios CSV y convierte los números a int.
    Si un archivo no existe, se salta. Si un renglón tiene datos malos, también."""
    trabajadores = []
    for ruta in rutas:
        if not Path(ruta).exists():
            continue
        for renglon in cargar_csv(ruta):
            try:
                for columna in COLUMNAS_NUMERICAS:
                    renglon[columna] = int(renglon[columna])
            except (KeyError, ValueError):
                continue        # renglón incompleto o con texto donde va un número
            trabajadores.append(renglon)
    return trabajadores


def guardar_trabajador(ruta, trabajador: dict) -> None:
    """Agrega un trabajador al final del CSV. Si el archivo es nuevo, escribe los encabezados."""
    ruta = Path(ruta)
    es_nuevo = not ruta.exists()
    ruta.parent.mkdir(parents=True, exist_ok=True)
    with ruta.open("a", encoding="utf-8", newline="") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=COLUMNAS)
        if es_nuevo:
            escritor.writeheader()
        escritor.writerow(trabajador)


def numero_registrado(trabajadores: list, numero: str) -> bool:
    """True si ya hay un trabajador con ese número (sin importar mayúsculas)."""
    for trabajador in trabajadores:
        if trabajador["numero"].strip().lower() == numero.strip().lower():
            return True
    return False


def eliminar_trabajador(rutas: list, numero: str) -> bool:
    """Borra al trabajador con ese número del primer CSV donde aparezca.
    Reescribe el archivo con los demás renglones. Regresa True si lo encontró."""
    for ruta in rutas:
        ruta = Path(ruta)
        if not ruta.exists():
            continue
        renglones = cargar_csv(ruta)
        quedan = []
        encontrado = False
        for renglon in renglones:
            if not encontrado and renglon["numero"] == numero:
                encontrado = True          # este es el que se borra: no se agrega a "quedan"
            else:
                quedan.append(renglon)
        if encontrado:
            with ruta.open("w", encoding="utf-8", newline="") as archivo:
                escritor = csv.DictWriter(archivo, fieldnames=COLUMNAS)
                escritor.writeheader()     # los encabezados siempre se conservan
                escritor.writerows(quedan)
            return True
    return False


def colonias_registradas(trabajadores: list) -> list:
    """Lista de colonias sin repetir, en orden alfabético (para el formulario)."""
    colonias = []
    for trabajador in trabajadores:
        if trabajador["colonia"] not in colonias:
            colonias.append(trabajador["colonia"])
    return sorted(colonias)
