"""Todos los números que usa LlegaBien y de dónde salen.

Regla del equipo: ningún número aparece en la app sin fuente.
Si un valor es un ejemplo o un supuesto, aquí se dice claramente.
Las referencias completas en formato APA están en docs/FUENTES.md.
"""

# ---------- Datos con fuente ----------

# Costo promedio de cada persona que rota (productividad perdida, nómina,
# contratación del reemplazo y finiquito). Estudio de Apli citado en
# Publimetro (Mendoza Rojas, 2022).
COSTO_POR_SALIDA = 47_000

# Costo de un empleado que renuncia antes de tres meses.
# Brivé Soluciones, citado en Expansión (2025). Es el costo más bajo que encontramos.
COSTO_SALIDA_TEMPRANA = 17_431

# Gasto de las fábricas en transporte de personal: entre 20,000 y 30,000 pesos
# por empleado al año (Milenio, 2020, citado en Mexico Business News).
# Usamos el punto medio para ESTIMAR una ruta; lo correcto es pedir cotización.
COSTO_TRANSPORTE_POR_TRABAJADOR_ANIO = 25_000

# Horas que pierde cada persona al año por el tráfico en la zona metropolitana
# de León, y las que pierde quien usa transporte público (IMCO, 2026).
HORAS_TRAFICO_LEON = 88
HORAS_TRAFICO_LEON_TRANSPORTE_PUBLICO = 132

# Minutos que ahorraron por trayecto las empresas de Nuevo León que
# escalonaron sus horarios de entrada (Publimetro, 2026).
AHORRO_HORARIO_ESCALONADO_MIN = 30

# ---------- Ejemplos y supuestos (la empresa los cambia por sus datos) ----------

# Empresa de ejemplo para la demostración en la feria.
EMPLEADOS_EJEMPLO = 200

# Rotación mensual de ejemplo. Como referencia, en 2017 el cónsul de Japón en
# el Bajío habló de 6 a 10 % al mes en empresas nuevas (El Financiero, 2017).
ROTACION_MENSUAL_EJEMPLO = 5.0

# Supuesto: 1 de cada 5 renuncias se debe al traslado.
# No es un dato publicado: cada empresa lo ajusta con sus entrevistas de salida.
PORCENTAJE_SALIDAS_POR_TRASLADO = 20.0

# ---------- Modelo de negocio (propuesta del equipo) ----------

# Mensualidad de LlegaBien por trabajador (pesos). Se validará en la feria.
PRECIO_POR_TRABAJADOR_MES = 30

# Textos cortos de fuente para mostrar debajo de los resultados
FUENTE_COSTO_SALIDA = "Costo por salida: $47,000 (Apli, citado en Publimetro, 2022)."
FUENTE_TRANSPORTE = ("Costo de transporte de personal: $20,000 a $30,000 por empleado al año "
                     "(Milenio, 2020, citado en Mexico Business News).")
FUENTE_ESCALONADO = ("En Nuevo León, las empresas con horarios escalonados ahorraron hasta "
                     "30 minutos por trayecto (Publimetro, 2026).")
