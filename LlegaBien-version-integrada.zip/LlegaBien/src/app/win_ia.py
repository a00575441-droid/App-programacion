"""Ventana Tkinter que consulta una IA mediante OpenRouter.

Diseño nuevo con el estilo de LlegaBien. La lógica de la consulta (consultar,
revisar_respuesta y enviar) es exactamente la misma de la actividad: tu API Key
se sigue escribiendo solo en el campo de la ventana.
"""

import queue                                    # "buzón" para pasar el resultado entre hilos
import threading                                # para consultar sin congelar la ventana
import tkinter as tk
from tkinter.scrolledtext import ScrolledText   # caja de texto con barra de scroll

import requests                                 # librería para hacer peticiones por internet

from src.app.estilo import (BLANCO, FUENTE, GRIS, GRIS_BORDE, GRIS_FONDO, GRIS_OSCURO, TINTA, VERDE,
                            VERDE_CLARO, VERDE_OSCURO, boton_primario, boton_secundario,
                            cargar_imagen, crear_ventana, linea, titulo_grande)

URL = "https://openrouter.ai/api/v1/chat/completions"   # a dónde se manda la pregunta
MODELO = "nvidia/nemotron-3.5-lightning:free"            # qué IA contesta (gratis)

# ---------- Solo diseño: cómo se ven las etiquetas y las cajas de texto ----------
ESTILO_ETIQUETA = {"bg": GRIS_FONDO, "fg": GRIS_OSCURO, "font": (FUENTE, 10, "bold")}
ESTILO_CAJA = {"bg": BLANCO, "fg": TINTA, "font": (FUENTE, 11), "relief": "flat", "bd": 0,
               "highlightthickness": 1, "highlightbackground": GRIS_BORDE, "highlightcolor": VERDE}


def open_win_ia(parent):
    """Abre una ventana para enviar preguntas y visualizar respuestas."""
    # ---------- Ventana secundaria con el encabezado de LlegaBien ----------
    win, frm, volver_menu = crear_ventana(parent, "Asistente con IA", "Asistente  /  IA",
                                          780, 720, con_scroll=False)

    # ---------- Mascota de LlegaBien a la izquierda, título y saludo a la derecha ----------
    presentacion = tk.Frame(frm, bg=GRIS_FONDO)
    presentacion.pack(fill="x")
    win.mascota = cargar_imagen("mascota_chat.png")   # se guarda en win para que Python no la borre
    if win.mascota is not None:                       # si falta el archivo, la ventana funciona igual
        tk.Label(presentacion, image=win.mascota, bg=GRIS_FONDO).pack(side="left", padx=(0, 16))
    lado_derecho = tk.Frame(presentacion, bg=GRIS_FONDO)
    lado_derecho.pack(side="left", fill="x", expand=True)
    titulo_grande(lado_derecho, "Pregúntale a ", "la IA.", tamano=22).pack(anchor="w")
    # "Globo de diálogo": un recuadro verde claro con el saludo de la mascota
    tk.Label(lado_derecho, text="¡Hola! Pregúntame lo que quieras sobre movilidad, traslados "
                                "o cómo usar LlegaBien.",
             bg=VERDE_CLARO, fg=VERDE_OSCURO, font=(FUENTE, 11), justify="left", wraplength=480,
             padx=12, pady=8).pack(anchor="w", pady=(6, 0))
    linea(frm, VERDE, 2).pack(fill="x", pady=(10, 10))

    # La parte de abajo se coloca primero para que el botón nunca se corte
    abajo = tk.Frame(frm, bg=GRIS_FONDO)
    abajo.pack(side="bottom", fill="x")

    # ---------- Controles: crear y colocar ----------
    tk.Label(frm, text="API Key de OpenRouter:", **ESTILO_ETIQUETA).pack(anchor="w")
    campo_clave = tk.Entry(frm, show="*", **ESTILO_CAJA)    # show="*" oculta la clave
    campo_clave.pack(fill="x", pady=(4, 12), ipady=5)

    tk.Label(frm, text="Escribe tu pregunta:", **ESTILO_ETIQUETA).pack(anchor="w")
    campo_pregunta = ScrolledText(frm, height=4, wrap="word", padx=8, pady=6, **ESTILO_CAJA)
    campo_pregunta.pack(fill="x", pady=(4, 12))

    tk.Label(frm, text="Respuesta de la IA:", **ESTILO_ETIQUETA).pack(anchor="w")
    campo_respuesta = ScrolledText(frm, height=9, wrap="word", padx=8, pady=6, **ESTILO_CAJA)
    campo_respuesta.pack(fill="both", expand=True, pady=(4, 8))

    estado = tk.Label(abajo, text="Listo para preguntar", bg=GRIS_FONDO, fg=GRIS, font=(FUENTE, 10))  # mensajito de abajo
    estado.pack(anchor="w")
    resultados = queue.Queue()                             # el buzón

    def consultar(api_key, pregunta):
        """Ejecuta la petición HTTP fuera del hilo de la interfaz."""
        try:
            # PROCESO: manda la pregunta a OpenRouter
            respuesta = requests.post(
                URL,                                         # la dirección
                headers={
                    "Authorization": f"Bearer {api_key}",    # tu credencial
                    "Content-Type": "application/json",
                },
                json={                                       # el pedido: un diccionario
                    "model": MODELO,
                    "messages": [{"role": "user", "content": pregunta}],
                    "max_tokens": 1000,                      # largo máximo de la respuesta
                },
                timeout=120,                                 # espera máximo 120 segundos
            )
            respuesta.raise_for_status()                     # si hubo error (401, 429...), salta al except
            datos = respuesta.json()                         # SALIDA: convierte la respuesta en diccionario
            texto = datos["choices"][0]["message"]["content"]   # "abre las cajas" hasta llegar al texto
            resultados.put(("ok", texto or "(El modelo no devolvió texto)"))
        except requests.exceptions.Timeout:
            resultados.put(("error", "Se agotó el tiempo de espera."))
        except requests.exceptions.HTTPError as error:
            codigo = error.response.status_code if error.response is not None else "desconocido"
            resultados.put(("error", f"OpenRouter devolvió HTTP {codigo}."))
        except requests.exceptions.RequestException as error:
            resultados.put(("error", f"No se pudo conectar: {error}"))
        except (ValueError, KeyError, IndexError, TypeError):
            resultados.put(("error", "La respuesta de la API no tiene el formato esperado."))

    def revisar_respuesta():
        """Actualiza los widgets desde el hilo principal de Tkinter."""
        if not win.winfo_exists():                 # si ya cerraron la ventana, no hace nada
            return
        try:
            tipo, texto = resultados.get_nowait()  # ¿ya hay algo en el buzón?
        except queue.Empty:
            win.after(150, revisar_respuesta)      # todavía no: vuelve a revisar en 150 ms
            return

        campo_respuesta.delete("1.0", "end")       # borra la caja (línea 1, columna 0, hasta el final)
        campo_respuesta.insert("end", texto)       # SALIDA: muestra la respuesta (en vez de print)
        estado.config(text="Consulta terminada" if tipo == "ok" else "Ocurrió un error")
        boton.config(state="normal")               # vuelve a activar el botón

    def enviar():
        # ENTRADA: lee lo que escribió el usuario (en vez de input)
        api_key = campo_clave.get().strip()
        pregunta = campo_pregunta.get("1.0", "end").strip()
        if not api_key or not pregunta:            # validación: ¿falta algo?
            estado.config(text="Escribe tu API Key y una pregunta.")
            return

        boton.config(state="disabled")             # evita mandar muchas preguntas seguidas
        estado.config(text="Consultando a la IA...")
        campo_respuesta.delete("1.0", "end")
        # Manda al "ayudante" (hilo) a hacer la consulta y empieza a revisar el buzón
        threading.Thread(target=consultar, args=(api_key, pregunta), daemon=True).start()
        revisar_respuesta()


    # EVENTO: al presionar el botón se ejecuta enviar (sin paréntesis)
    botones = tk.Frame(abajo, bg=GRIS_FONDO)
    botones.pack(fill="x", pady=8)
    boton = boton_primario(botones, "Preguntar a la IA", enviar)
    boton.pack(side="left", padx=(0, 14))
    boton_secundario(botones, "Volver al menú", volver_menu).pack(side="left")
