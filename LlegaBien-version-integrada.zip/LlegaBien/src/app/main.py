"""Menú principal de LlegaBien — TC1038 Movilidad Inteligente."""
from pathlib import Path
import sys
import tkinter as tk

# Permite importar "src.app..." y "src.core..." aunque se ejecute este archivo directo
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.app.estilo import (BLANCO, FUENTE, GRIS, GRIS_BORDE, GRIS_FONDO, GRIS_OSCURO,
                            GRIS_SUAVE, TINTA, VERDE, VERDE_CLARO, VERDE_OSCURO,
                            cargar_imagen, configurar_estilos_ttk, linea, subtitulo,
                            titulo_grande)
from src.app.win_home import open_win_home            # 1. Inicio (lo hizo nuestro compañero)
from src.app.win_form import open_win_form            # 2. Registrar trabajador
from src.app.win_table import open_win_table          # 3. Plantilla
from src.app.win_dashboard import open_win_dashboard  # 4. Diagnóstico (el costo en pesos)
from src.app.win_plan import open_win_plan            # 5. Plan de acción (rutas y horarios)
from src.app.win_ia import open_win_ia                # 6. Asistente con IA


def crear_tarjeta(contenedor, raiz, numero, titulo, descripcion, icono, flecha, funcion, destacada):
    """Crea una tarjeta blanca con ícono, número, título, descripción y flecha.
    Al dar clic en cualquier parte de la tarjeta se abre la ventana de 'funcion'."""
    color_borde = VERDE if destacada else GRIS_BORDE
    grosor_borde = 2 if destacada else 1

    # El borde se dibuja con highlightthickness (grosor) y highlightbackground (color)
    tarjeta = tk.Frame(contenedor, bg=BLANCO, padx=14, pady=8,
                       highlightthickness=grosor_borde, highlightbackground=color_borde)
    tarjeta.pack(fill="x", pady=4)
    tarjeta.columnconfigure(2, weight=1)   # la columna del título se estira

    # Columna 0: ícono (ocupa los 2 renglones). Si no hay imagen, un cuadro verde claro
    if icono is not None:
        tk.Label(tarjeta, image=icono, bg=BLANCO).grid(row=0, column=0, rowspan=2, padx=(0, 14))
    else:
        tk.Label(tarjeta, text="", bg=VERDE_CLARO, width=4, height=2).grid(row=0, column=0, rowspan=2, padx=(0, 14))
    # Renglón 0: número verde + título
    tk.Label(tarjeta, text=numero, bg=BLANCO, fg=VERDE,
             font=(FUENTE, 10, "bold")).grid(row=0, column=1, sticky="w", padx=(0, 6))
    tk.Label(tarjeta, text=titulo, bg=BLANCO, fg=TINTA,
             font=(FUENTE, 13, "bold")).grid(row=0, column=2, sticky="w")
    # Renglón 1: descripción gris (ocupa las columnas 1 y 2)
    tk.Label(tarjeta, text=descripcion, bg=BLANCO, fg=GRIS,
             font=(FUENTE, 10)).grid(row=1, column=1, columnspan=2, sticky="w")
    # Columna 3: flecha a la derecha. Si no hay imagen, el símbolo ›
    if flecha is not None:
        tk.Label(tarjeta, image=flecha, bg=BLANCO).grid(row=0, column=3, rowspan=2, padx=(10, 0))
    else:
        tk.Label(tarjeta, text="›", bg=BLANCO, fg=GRIS_SUAVE,
                 font=(FUENTE, 18)).grid(row=0, column=3, rowspan=2, padx=(10, 0))

    def abrir(evento):
        tarjeta.configure(highlightbackground=color_borde)   # quita el contorno verde antes de esconder el menú
        funcion(raiz)

    # La tarjeta y todo lo que tiene adentro responden al mouse
    widgets = [tarjeta] + tarjeta.winfo_children()
    for widget in widgets:
        widget.configure(cursor="hand2")                                   # manita
        widget.bind("<Button-1>", abrir)                                    # clic: abre la ventana
        widget.bind("<Enter>", lambda evento: tarjeta.configure(highlightbackground=VERDE))
        widget.bind("<Leave>", lambda evento: tarjeta.configure(highlightbackground=color_borde))


def main():
    root = tk.Tk()
    root.title("LlegaBien")
    root.minsize(720, 0)          # ancho mínimo; el alto se ajusta solo al contenido
    root.configure(bg=GRIS_FONDO)
    configurar_estilos_ttk(root)

    # Las imágenes se guardan en root para que Python no las borre
    root.imagenes = {
        "icono": cargar_imagen("icono_llegabien.png"),
        "logo": cargar_imagen("logo_llegabien.png"),
        "flecha": cargar_imagen("flecha.png"),
        "salir": cargar_imagen("ic_salir.png"),
        "inicio": cargar_imagen("ic_inicio.png"),
        "registrar": cargar_imagen("ic_registrar.png"),
        "tabla": cargar_imagen("ic_tabla.png"),
        "diagnostico": cargar_imagen("ic_diagnostico_destacado.png"),
        "plan": cargar_imagen("ic_plan.png"),
        "ia": cargar_imagen("ic_ia.png"),
    }
    if root.imagenes["icono"] is not None:
        root.iconphoto(True, root.imagenes["icono"])   # ícono de la barra de la ventana

    # ---------- Encabezado: logo a la izquierda, "migas" a la derecha (como en el Inicio) ----------
    encabezado = tk.Frame(root, bg=GRIS_FONDO, padx=30, pady=12)
    encabezado.pack(fill="x")
    if root.imagenes["logo"] is not None:
        tk.Label(encabezado, image=root.imagenes["logo"], bg=GRIS_FONDO).pack(side="left")
    else:   # sin imagen: el nombre escrito
        tk.Label(encabezado, text="LlegaBien", bg=GRIS_FONDO, fg=TINTA,
                 font=(FUENTE, 20, "bold")).pack(side="left")
    tk.Label(encabezado, text="Menú principal", bg=GRIS_FONDO, fg=GRIS_OSCURO,
             font=(FUENTE, 11)).pack(side="right")
    linea(root).pack(fill="x")

    contenido = tk.Frame(root, bg=GRIS_FONDO, padx=30, pady=16)
    contenido.pack(fill="both", expand=True)

    # ---------- Título de dos colores y subtítulo ----------
    titulo_grande(contenido, "¿Qué quieres ", "hacer hoy?").pack(anchor="w")
    subtitulo(contenido, "Diagnóstico del traslado de tu plantilla. Elige una opción.").pack(anchor="w", pady=(2, 10))
    linea(contenido, VERDE, 2).pack(fill="x", pady=(0, 10))

    # ---------- Tarjetas: (número, título, descripción, ícono, función, destacada) ----------
    opciones = [
        ("1", "Inicio", "El problema y lo que ofrece LlegaBien", "inicio", open_win_home, False),
        ("2", "Registrar trabajador", "Captura cómo llega cada trabajador", "registrar", open_win_form, False),
        ("3", "Plantilla", "Riesgo de traslado de cada trabajador", "tabla", open_win_table, False),
        ("4", "Diagnóstico", "Cuánto te cuestan las renuncias por traslado", "diagnostico", open_win_dashboard, False),
        ("5", "Plan de acción", "Rutas y horarios para llegar a tiempo y con menos tráfico", "plan", open_win_plan, False),
        ("6", "Asistente con IA", "Pregúntale lo que quieras a la IA (OpenRouter)", "ia", open_win_ia, False),
    ]
    for numero, titulo, descripcion, icono, funcion, destacada in opciones:
        crear_tarjeta(contenido, root, numero, titulo, descripcion, root.imagenes[icono],
                      root.imagenes["flecha"], funcion, destacada)

    # ---------- Pie: botón Salir y texto ----------
    pie = tk.Frame(contenido, bg=GRIS_FONDO)
    pie.pack(fill="x", pady=(14, 0))
    borde_salir = tk.Frame(pie, bg=VERDE, padx=2, pady=2)   # marco verde = borde del botón
    borde_salir.pack(side="left")
    # Si falta la imagen, image=None hace que el botón solo muestre el texto
    tk.Button(borde_salir, text="  Salir", image=root.imagenes["salir"], compound="left",
              bg=BLANCO, fg=VERDE_OSCURO, activebackground=VERDE_CLARO, activeforeground=VERDE_OSCURO,
              font=(FUENTE, 11, "bold"), relief="flat", bd=0, padx=16, pady=6, cursor="hand2",
              command=root.destroy).pack()
    tk.Label(pie, text="Movilidad laboral · León, Guanajuato", bg=GRIS_FONDO, fg=GRIS_SUAVE,
             font=(FUENTE, 10)).pack(side="right")

    root.mainloop()


if __name__ == "__main__":
    main()
