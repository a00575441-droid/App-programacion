"""Ventana 3 · Plantilla: el riesgo de traslado de cada trabajador (usa F1 y F2).
También permite eliminar a un trabajador."""
import tkinter as tk
from tkinter import messagebox, ttk

from src.app.estilo import (BLANCO, COLOR_RIESGO, FONDO_RIESGO, FUENTE, GRIS, GRIS_FONDO, ROJO,
                            TINTA, VERDE, boton_peligro, boton_secundario, crear_ventana, linea,
                            subtitulo, texto_pequeno, titulo_grande)
from src.core.data_io import RUTA_EJEMPLO, RUTA_USUARIO, cargar_trabajadores, eliminar_trabajador
from src.core.logic import REGLA_RIESGO, clasificar_riesgo, resumir_plantilla

COLUMNAS = [  # (clave, encabezado, ancho)
    ("numero", "Número", 80), ("colonia", "Colonia", 170), ("hora_entrada", "Entrada", 80),
    ("medio", "Medio", 170), ("minutos", "Minutos", 80), ("transbordos", "Transbordos", 100),
    ("retardos", "Retardos/mes", 100), ("riesgo", "Riesgo", 90),
]
CLAVES = [clave for clave, _, _ in COLUMNAS]
ORDEN_RIESGO = {"ALTO": 0, "MEDIO": 1, "BAJO": 2}
ARCHIVOS = [RUTA_EJEMPLO, RUTA_USUARIO]


def open_win_table(parent):
    win, cuerpo, volver_menu = crear_ventana(parent, "Plantilla", "Plantilla  /  riesgo por trabajador",
                                             1000, 660, con_scroll=False)

    titulo_grande(cuerpo, "Tu ", "plantilla.").pack(anchor="w")
    resumen_texto = subtitulo(cuerpo, "")
    resumen_texto.pack(anchor="w", pady=(2, 8))
    linea(cuerpo, VERDE, 2).pack(fill="x", pady=(0, 10))

    # ---------- Leyenda del semáforo ----------
    leyenda = tk.Frame(cuerpo, bg=GRIS_FONDO)
    leyenda.pack(anchor="w", pady=(0, 8))
    for nivel in ("ALTO", "MEDIO", "BAJO"):
        tk.Label(leyenda, text=f" {nivel} ", bg=FONDO_RIESGO[nivel], fg=COLOR_RIESGO[nivel],
                 font=(FUENTE, 9, "bold")).pack(side="left")
        tk.Label(leyenda, text=f" {REGLA_RIESGO[nivel]}", bg=GRIS_FONDO,
                 font=(FUENTE, 9)).pack(side="left", padx=(0, 14))

    # ---------- Parte de abajo primero, para que los botones nunca se corten ----------
    abajo = tk.Frame(cuerpo, bg=GRIS_FONDO)
    abajo.pack(side="bottom", fill="x")
    seleccion = tk.Label(abajo, text="Para eliminar: haz clic en un trabajador de la tabla.",
                         bg=GRIS_FONDO, fg=GRIS, font=(FUENTE, 10, "bold"))
    seleccion.pack(anchor="w", pady=(8, 0))
    texto_pequeno(abajo, "E001 a E036 son datos de ejemplo (ficticios) para la demostración. "
                         "Los trabajadores que registres se agregan a la lista.").pack(anchor="w")
    botones = tk.Frame(abajo, bg=GRIS_FONDO)
    botones.pack(fill="x", pady=(14, 4))

    # ---------- Tabla (los de riesgo alto primero) ----------
    zona_tabla = tk.Frame(cuerpo, bg=BLANCO)
    zona_tabla.pack(fill="both", expand=True)
    tabla = ttk.Treeview(zona_tabla, columns=CLAVES, show="headings", height=12, selectmode="browse")
    for clave, encabezado, ancho in COLUMNAS:
        tabla.heading(clave, text=encabezado)
        tabla.column(clave, width=ancho, anchor="center")
    for nivel in ("ALTO", "MEDIO", "BAJO"):
        tabla.tag_configure(nivel, background=FONDO_RIESGO[nivel])   # color del renglón según riesgo
    barra = ttk.Scrollbar(zona_tabla, orient="vertical", command=tabla.yview)
    tabla.configure(yscrollcommand=barra.set)
    tabla.pack(side="left", fill="both", expand=True)
    barra.pack(side="right", fill="y")

    # Guardamos el número y la colonia de cada renglón tal como vienen del archivo.
    # (Si los leyéramos de la tabla, Tkinter convertiría "001" en 1 y no lo encontraríamos.)
    datos_renglon = {}

    def llenar_tabla():
        """Lee los CSV, calcula el riesgo (F1) y el resumen (F2), y vuelve a llenar la tabla."""
        trabajadores = cargar_trabajadores(ARCHIVOS)
        for trabajador in trabajadores:
            trabajador["riesgo"] = clasificar_riesgo(trabajador["minutos"], trabajador["transbordos"])
        resumen = resumir_plantilla(trabajadores)
        resumen_texto.config(text=f"{resumen['total']} trabajadores · {resumen['ALTO']} en riesgo alto · "
                                  f"{resumen['porcentaje_largos']:.0f} % tarda 60 minutos o más")
        for renglon in tabla.get_children():          # borra lo que había
            tabla.delete(renglon)
        datos_renglon.clear()
        ordenados = sorted(trabajadores, key=lambda t: (ORDEN_RIESGO[t["riesgo"]], -t["minutos"]))
        for trabajador in ordenados:
            valores = [trabajador[clave] for clave in CLAVES]
            renglon = tabla.insert("", "end", values=valores, tags=(trabajador["riesgo"],))
            datos_renglon[renglon] = (trabajador["numero"], trabajador["colonia"])

    def trabajador_seleccionado():
        """Regresa (número, colonia) del renglón seleccionado, o None si no hay ninguno."""
        elegidos = tabla.selection()
        if not elegidos:
            return None
        return datos_renglon[elegidos[0]]

    def al_seleccionar(evento=None):
        elegido = trabajador_seleccionado()
        if elegido is not None:
            seleccion.config(text=f"Seleccionado: {elegido[0]} · {elegido[1]}", fg=TINTA)

    def eliminar():
        elegido = trabajador_seleccionado()
        if elegido is None:
            seleccion.config(text="Primero haz clic en un trabajador de la tabla.", fg=ROJO)
            return
        numero, colonia = elegido
        # Pregunta antes de borrar, porque no se puede deshacer
        seguro = messagebox.askyesno("Eliminar trabajador",
                                     f"¿Seguro que quieres eliminar a {numero} ({colonia})?\n\n"
                                     "Esto no se puede deshacer.", parent=win)
        if not seguro:
            return
        try:
            borrado = eliminar_trabajador(ARCHIVOS, numero)
        except OSError as error:
            seleccion.config(text=f"No se pudo borrar. ¿Está abierto el archivo en Excel? ({error})", fg=ROJO)
            return
        if borrado:
            llenar_tabla()
            seleccion.config(text=f"Listo: {numero} se eliminó.", fg=VERDE)
        else:
            seleccion.config(text=f"No se encontró a {numero} en los archivos.", fg=ROJO)

    tabla.bind("<<TreeviewSelect>>", al_seleccionar)
    boton_peligro(botones, "Eliminar trabajador", eliminar).pack(side="left", padx=(0, 14))
    boton_secundario(botones, "Volver al menú", volver_menu).pack(side="left")
    win.bind("<Delete>", lambda evento: eliminar())     # la tecla Supr también elimina

    llenar_tabla()
    return win
