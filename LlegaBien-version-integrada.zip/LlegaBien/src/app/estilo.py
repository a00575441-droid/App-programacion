"""Estilo visual compartido de LlegaBien: colores, letras, encabezado y botones.

Todas las ventanas usan estas funciones para verse igual que la pantalla de Inicio.
Así el diseño se cambia en un solo lugar y no repetimos código en cada archivo.
"""
from pathlib import Path
import tkinter as tk
from tkinter import ttk

# ---------- Paleta de LlegaBien (sacada del logo y de la pantalla de Inicio) ----------
VERDE = "#01847D"
VERDE_OSCURO = "#016A64"
VERDE_CLARO = "#E2F2EF"
BLANCO = "#FFFFFF"
GRIS_FONDO = "#F0F3F2"
GRIS_BORDE = "#DCE2E0"
GRIS_OSCURO = "#2B3332"
GRIS = "#56605E"
GRIS_SUAVE = "#8A9491"
TINTA = "#14213D"            # azul marino casi negro de los títulos del Inicio
ROJO = "#C2413B"
ROJO_CLARO = "#FBE5E3"
AMARILLO = "#B7791F"
AMARILLO_CLARO = "#FFF4DA"

# Colores del semáforo de riesgo
COLOR_RIESGO = {"ALTO": ROJO, "MEDIO": AMARILLO, "BAJO": VERDE}
FONDO_RIESGO = {"ALTO": ROJO_CLARO, "MEDIO": AMARILLO_CLARO, "BAJO": VERDE_CLARO}

FUENTE = "Segoe UI"
FUENTE_TITULO = "Segoe UI Black"   # letra gruesa como "Cada llegada cuenta."

ASSETS = Path(__file__).resolve().parent / "assets"


def cargar_imagen(nombre_archivo):
    """Abre un PNG de la carpeta assets. Si no existe, regresa None en lugar de detener la app."""
    try:
        return tk.PhotoImage(file=str(ASSETS / nombre_archivo))
    except tk.TclError:
        print("Aviso: no se encontró", ASSETS / nombre_archivo)
        return None


def configurar_estilos_ttk(raiz):
    """Colores para los controles ttk (tabla y listas desplegables). Se llama una vez en main."""
    estilo = ttk.Style(raiz)
    estilo.theme_use("clam")       # el tema "clam" sí deja cambiar colores
    estilo.configure("Treeview", background=BLANCO, fieldbackground=BLANCO, foreground=GRIS_OSCURO,
                     rowheight=28, font=(FUENTE, 10), bordercolor=GRIS_BORDE)
    estilo.configure("Treeview.Heading", background=VERDE_CLARO, foreground=VERDE_OSCURO,
                     font=(FUENTE, 10, "bold"), relief="flat")
    estilo.map("Treeview.Heading", background=[("active", VERDE_CLARO)])
    estilo.map("Treeview", background=[("selected", VERDE)], foreground=[("selected", BLANCO)])
    estilo.configure("TCombobox", fieldbackground=BLANCO, background=BLANCO, padding=5,
                     bordercolor=GRIS_BORDE, arrowcolor=VERDE)
    raiz.option_add("*TCombobox*Listbox.font", (FUENTE, 10))


# ---------- Piezas pequeñas ----------
def linea(padre, color=GRIS_BORDE, grosor=1):
    """Línea horizontal (un Frame delgado). Hay que hacerle pack(fill="x")."""
    return tk.Frame(padre, bg=color, height=grosor)


def titulo_grande(padre, texto_oscuro, texto_verde, tamano=26, fondo=GRIS_FONDO):
    """Título de dos colores como en el Inicio: "Cada llegada " + "cuenta."."""
    marco = tk.Frame(padre, bg=fondo)
    tk.Label(marco, text=texto_oscuro, bg=fondo, fg=TINTA,
             font=(FUENTE_TITULO, tamano)).pack(side="left")
    tk.Label(marco, text=texto_verde, bg=fondo, fg=VERDE,
             font=(FUENTE_TITULO, tamano)).pack(side="left")
    return marco


def subtitulo(padre, texto, fondo=GRIS_FONDO, ancho=820):
    return tk.Label(padre, text=texto, bg=fondo, fg=GRIS_OSCURO, font=(FUENTE, 12),
                    justify="left", wraplength=ancho)


def texto_pequeno(padre, texto, fondo=GRIS_FONDO, ancho=820, color=GRIS):
    return tk.Label(padre, text=texto, bg=fondo, fg=color, font=(FUENTE, 9),
                    justify="left", wraplength=ancho)


def encabezado_seccion(padre, texto, fondo=GRIS_FONDO):
    return tk.Label(padre, text=texto, bg=fondo, fg=TINTA, font=(FUENTE, 13, "bold"))


def boton_primario(padre, texto, comando):
    """Botón verde lleno, como "¿Por qué importa?"."""
    return tk.Button(padre, text=texto, command=comando, bg=VERDE, fg=BLANCO,
                     activebackground=VERDE_OSCURO, activeforeground=BLANCO,
                     font=(FUENTE, 11, "bold"), relief="flat", bd=0,
                     padx=18, pady=7, cursor="hand2")


def boton_secundario(padre, texto, comando):
    """Botón con contorno, como "Volver al menú". El Frame oscuro hace de borde."""
    borde = tk.Frame(padre, bg=GRIS_OSCURO, padx=1, pady=1)
    tk.Button(borde, text=texto, command=comando, bg=GRIS_FONDO, fg=TINTA,
              activebackground=BLANCO, activeforeground=TINTA, font=(FUENTE, 11),
              relief="flat", bd=0, padx=18, pady=6, cursor="hand2").pack()
    return borde


def boton_peligro(padre, texto, comando):
    """Botón con contorno rojo para acciones que borran algo."""
    borde = tk.Frame(padre, bg=ROJO, padx=1, pady=1)
    tk.Button(borde, text=texto, command=comando, bg=GRIS_FONDO, fg=ROJO,
              activebackground=ROJO_CLARO, activeforeground=ROJO, font=(FUENTE, 11, "bold"),
              relief="flat", bd=0, padx=18, pady=6, cursor="hand2").pack()
    return borde


def tarjeta(padre, padx=16, pady=12):
    """Rectángulo blanco con borde gris (para agrupar información)."""
    return tk.Frame(padre, bg=BLANCO, padx=padx, pady=pady,
                    highlightthickness=1, highlightbackground=GRIS_BORDE)


def tarjeta_dato(padre, valor, etiqueta, color=TINTA):
    """Tarjeta con un número grande y su explicación. Regresa (tarjeta, etiqueta_del_valor)
    para poder cambiar el número después con .config(text=...)."""
    caja = tarjeta(padre, padx=14, pady=10)
    etiqueta_valor = tk.Label(caja, text=valor, bg=BLANCO, fg=color, font=(FUENTE_TITULO, 18))
    etiqueta_valor.pack(anchor="w")
    tk.Label(caja, text=etiqueta, bg=BLANCO, fg=GRIS, font=(FUENTE, 9),
             justify="left", wraplength=180).pack(anchor="w")
    return caja, etiqueta_valor


def crear_campo(padre, texto, fila, columna, valor="", ancho=18, fondo=GRIS_FONDO):
    """Etiqueta arriba y cuadro de texto abajo, colocados con grid. Regresa el Entry."""
    marco = tk.Frame(padre, bg=fondo)
    marco.grid(row=fila, column=columna, sticky="ew", padx=(0, 16), pady=6)
    tk.Label(marco, text=texto, bg=fondo, fg=GRIS_OSCURO, font=(FUENTE, 10, "bold")).pack(anchor="w")
    campo = tk.Entry(marco, width=ancho, font=(FUENTE, 11), bg=BLANCO, fg=TINTA, relief="flat",
                     highlightthickness=1, highlightbackground=GRIS_BORDE, highlightcolor=VERDE)
    campo.pack(fill="x", ipady=5, pady=(3, 0))
    campo.insert(0, str(valor))
    return campo


def crear_lista(padre, texto, fila, columna, opciones, solo_lectura=False, fondo=GRIS_FONDO):
    """Etiqueta arriba y lista desplegable (Combobox) abajo. Regresa el Combobox."""
    marco = tk.Frame(padre, bg=fondo)
    marco.grid(row=fila, column=columna, sticky="ew", padx=(0, 16), pady=6)
    tk.Label(marco, text=texto, bg=fondo, fg=GRIS_OSCURO, font=(FUENTE, 10, "bold")).pack(anchor="w")
    estado = "readonly" if solo_lectura else "normal"
    lista = ttk.Combobox(marco, values=opciones, state=estado, font=(FUENTE, 11))
    lista.pack(fill="x", pady=(3, 0))
    return lista


def crear_area_con_scroll(padre):
    """Área con barra de desplazamiento, por si la pantalla de la laptop es chica.
    Regresa el Frame donde se colocan los controles."""
    lienzo = tk.Canvas(padre, bg=GRIS_FONDO, highlightthickness=0)
    barra = ttk.Scrollbar(padre, orient="vertical", command=lienzo.yview)
    contenido = tk.Frame(lienzo, bg=GRIS_FONDO, padx=28, pady=16)
    id_contenido = lienzo.create_window((0, 0), window=contenido, anchor="nw")

    # Cuando cambia el tamaño, se actualiza la zona que se puede recorrer
    contenido.bind("<Configure>", lambda evento: lienzo.configure(scrollregion=lienzo.bbox("all")))
    lienzo.bind("<Configure>", lambda evento: lienzo.itemconfigure(id_contenido, width=evento.width))
    lienzo.configure(yscrollcommand=barra.set)
    lienzo.pack(side="left", fill="both", expand=True)
    barra.pack(side="right", fill="y")

    def mover_con_rueda(evento):
        # Solo se mueve si el contenido es más alto que la ventana
        if contenido.winfo_height() > lienzo.winfo_height():
            lienzo.yview_scroll(int(-evento.delta / 120), "units")

    # La rueda del mouse funciona en cualquier parte de esta ventana
    padre.winfo_toplevel().bind("<MouseWheel>", mover_con_rueda)
    return contenido


# ---------- La ventana completa ----------
def crear_ventana(parent, titulo, migas, ancho=920, alto=660, con_scroll=True):
    """Crea una ventana secundaria con el encabezado de LlegaBien.

    Igual que el Inicio de nuestro compañero: esconde el menú mientras está abierta
    y lo vuelve a mostrar al cerrar. Regresa (win, cuerpo, volver_menu).
    """
    win = tk.Toplevel(parent)
    win.title(f"LlegaBien — {titulo}")
    win.configure(bg=GRIS_FONDO)
    # Si la pantalla es chica, la ventana se hace más pequeña
    ancho = min(ancho, win.winfo_screenwidth() - 60)
    alto = min(alto, win.winfo_screenheight() - 100)
    win.geometry(f"{ancho}x{alto}")
    win.minsize(720, 480)

    def volver_menu():
        win.destroy()
        parent.deiconify()
        parent.lift()
        parent.focus_set()

    win.protocol("WM_DELETE_WINDOW", volver_menu)    # la X de la ventana también regresa al menú
    win.bind("<Escape>", lambda evento: volver_menu())

    # Encabezado: logo a la izquierda y "migas de pan" a la derecha (como "Inicio / propuesta")
    encabezado = tk.Frame(win, bg=GRIS_FONDO, padx=28, pady=12)
    encabezado.pack(fill="x")
    win.logo = cargar_imagen("logo_llegabien.png")     # se guarda en win para que Python no la borre
    if win.logo is not None:
        tk.Label(encabezado, image=win.logo, bg=GRIS_FONDO).pack(side="left")
    else:
        tk.Label(encabezado, text="LlegaBien", bg=GRIS_FONDO, fg=TINTA,
                 font=(FUENTE_TITULO, 18)).pack(side="left")
    tk.Label(encabezado, text=migas, bg=GRIS_FONDO, fg=GRIS_OSCURO, font=(FUENTE, 11)).pack(side="right")
    linea(win).pack(fill="x")

    if con_scroll:
        zona = tk.Frame(win, bg=GRIS_FONDO)
        zona.pack(fill="both", expand=True)
        cuerpo = crear_area_con_scroll(zona)
    else:
        cuerpo = tk.Frame(win, bg=GRIS_FONDO, padx=28, pady=16)
        cuerpo.pack(fill="both", expand=True)

    parent.withdraw()
    win.focus_set()
    return win, cuerpo, volver_menu


def fila_de_botones(padre, volver_menu, texto_principal=None, comando_principal=None):
    """Fila inferior como en el Inicio: botón verde (opcional) y "Volver al menú"."""
    fila = tk.Frame(padre, bg=GRIS_FONDO)
    fila.pack(fill="x", pady=(18, 4))
    if texto_principal is not None:
        boton_primario(fila, texto_principal, comando_principal).pack(side="left", padx=(0, 14))
    boton_secundario(fila, "Volver al menú", volver_menu).pack(side="left")
    return fila
