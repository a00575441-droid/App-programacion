"""Ventana 4 · Diagnóstico: cuánto le cuestan a la empresa las renuncias por traslado.

Es la pantalla que se le enseña al dueño: el problema en pesos.
Usa F2, F3, F4, F5 y F7, y calcula el precio de LlegaBien.
"""
import tkinter as tk

from src.app.estilo import (BLANCO, COLOR_RIESGO, FUENTE, GRIS, GRIS_FONDO, ROJO, TINTA, VERDE,
                            crear_campo, crear_ventana, encabezado_seccion, fila_de_botones, linea,
                            subtitulo, tarjeta, tarjeta_dato, texto_pequeno, titulo_grande)
from src.core.data_io import RUTA_EJEMPLO, RUTA_USUARIO, cargar_trabajadores
from src.core.datos_referencia import (COSTO_POR_SALIDA, EMPLEADOS_EJEMPLO, FUENTE_COSTO_SALIDA,
                                       PORCENTAJE_SALIDAS_POR_TRASLADO, PRECIO_POR_TRABAJADOR_MES,
                                       ROTACION_MENSUAL_EJEMPLO)
from src.core.logic import (calcular_costo_llegabien, calcular_costo_rotacion,
                            colonias_con_mas_riesgo, convertir_numero, formato_pesos,
                            generar_alertas, hora_con_mas_retardos, plural, resumir_plantilla)


def dibujar_semaforo(lienzo, resumen, ancho=400):
    """Barras horizontales con cuántos trabajadores hay en cada nivel de riesgo."""
    x_inicio = 70
    largo_maximo = ancho - x_inicio - 50
    for i, nivel in enumerate(("ALTO", "MEDIO", "BAJO")):
        y = 12 + i * 40
        cantidad = resumen[nivel]
        largo = largo_maximo * cantidad / resumen["total"] if resumen["total"] else 0
        lienzo.create_text(8, y + 12, text=nivel, anchor="w", fill=COLOR_RIESGO[nivel],
                           font=(FUENTE, 10, "bold"))
        lienzo.create_rectangle(x_inicio, y, x_inicio + largo, y + 24,
                                fill=COLOR_RIESGO[nivel], outline="")
        lienzo.create_text(x_inicio + largo + 8, y + 12, text=str(cantidad), anchor="w",
                           fill=TINTA, font=(FUENTE, 10, "bold"))


def open_win_dashboard(parent):
    win, cuerpo, volver_menu = crear_ventana(parent, "Diagnóstico", "Diagnóstico  /  costo de la rotación",
                                             1000, 720)

    trabajadores = cargar_trabajadores([RUTA_EJEMPLO, RUTA_USUARIO])
    resumen = resumir_plantilla(trabajadores)                        # F2
    titulo_grande(cuerpo, "Lo que te cuesta ", "el traslado.").pack(anchor="w")

    if resumen["total"] == 0:
        subtitulo(cuerpo, "Todavía no hay trabajadores. Registra algunos en la opción 2.").pack(anchor="w")
        fila_de_botones(cuerpo, volver_menu)
        return win

    colonias = colonias_con_mas_riesgo(trabajadores)                 # F3
    hora, promedio_retardos = hora_con_mas_retardos(trabajadores)    # F5
    alertas = generar_alertas(resumen["porcentaje_largos"], colonias)  # F7

    subtitulo(cuerpo, f"Encuesta de {resumen['total']} trabajadores. Abajo cambia los datos de tu empresa "
                      "y presiona Recalcular.").pack(anchor="w", pady=(2, 8))
    linea(cuerpo, VERDE, 2).pack(fill="x", pady=(0, 12))

    # ---------- Fila 1: cuatro tarjetas con los números clave ----------
    fila_tarjetas = tk.Frame(cuerpo, bg=GRIS_FONDO)
    fila_tarjetas.pack(fill="x")
    datos_tarjetas = [
        (f"{resumen['ALTO']} de {resumen['total']}", "trabajadores con traslado de riesgo alto", ROJO),
        (f"{resumen['porcentaje_largos']:.0f} %", "tarda 60 minutos o más en llegar", TINTA),
        ("$0", "al año en renuncias por traslado (estimado)", ROJO),
        (hora, f"hora de entrada con más retardos ({promedio_retardos:.1f} al mes por persona)", TINTA),
    ]
    valores = []      # guardamos las etiquetas de los números para actualizarlas
    for columna, (valor, explicacion, color) in enumerate(datos_tarjetas):
        caja, etiqueta_valor = tarjeta_dato(fila_tarjetas, valor, explicacion, color)
        caja.grid(row=0, column=columna, sticky="nsew", padx=(0, 10))
        fila_tarjetas.columnconfigure(columna, weight=1)
        valores.append(etiqueta_valor)
    valor_costo = valores[2]

    # ---------- Fila 2: semáforo | colonias y alertas ----------
    fila_media = tk.Frame(cuerpo, bg=GRIS_FONDO)
    fila_media.pack(fill="x", pady=12)
    fila_media.columnconfigure(0, weight=1)
    fila_media.columnconfigure(1, weight=1)

    caja_semaforo = tarjeta(fila_media)
    caja_semaforo.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
    encabezado_seccion(caja_semaforo, "Semáforo de la plantilla", BLANCO).pack(anchor="w")
    lienzo = tk.Canvas(caja_semaforo, width=400, height=132, bg=BLANCO, highlightthickness=0)
    lienzo.pack(anchor="w", pady=(6, 0))
    dibujar_semaforo(lienzo, resumen)

    caja_colonias = tarjeta(fila_media)
    caja_colonias.grid(row=0, column=1, sticky="nsew", padx=(0, 10))
    encabezado_seccion(caja_colonias, "Colonias con más riesgo alto", BLANCO).pack(anchor="w")
    if not colonias:
        tk.Label(caja_colonias, text="Ninguna colonia en riesgo alto.", bg=BLANCO, fg=GRIS,
                 font=(FUENTE, 10)).pack(anchor="w")
    for lugar, (colonia, conteo) in enumerate(colonias, start=1):
        tk.Label(caja_colonias, text=f"{lugar}. {colonia}: {conteo} trabajadores", bg=BLANCO,
                 fg=TINTA, font=(FUENTE, 11)).pack(anchor="w")
    encabezado_seccion(caja_colonias, "Alertas para RH", BLANCO).pack(anchor="w", pady=(10, 0))
    if not alertas:
        tk.Label(caja_colonias, text="Sin alertas por ahora.", bg=BLANCO, fg=GRIS,
                 font=(FUENTE, 10)).pack(anchor="w")
    for alerta in alertas:
        tk.Label(caja_colonias, text=f"• {alerta}", bg=BLANCO, fg=ROJO, font=(FUENTE, 10, "bold"),
                 justify="left", wraplength=380).pack(anchor="w")

    # ---------- Fila 3: datos de la empresa (F4) y precio de LlegaBien ----------
    caja_empresa = tarjeta(cuerpo)
    caja_empresa.pack(fill="x", padx=(0, 10))
    encabezado_seccion(caja_empresa, "Datos de tu empresa", BLANCO).pack(anchor="w")
    texto_pequeno(caja_empresa, "Vienen con valores de ejemplo. Cámbialos por los de tu empresa.",
                  BLANCO).pack(anchor="w")
    campos = tk.Frame(caja_empresa, bg=BLANCO)
    campos.pack(fill="x", pady=(4, 6))
    for columna in range(4):
        campos.columnconfigure(columna, weight=1)
    campo_empleados = crear_campo(campos, "Empleados", 0, 0, EMPLEADOS_EJEMPLO, 10, BLANCO)
    campo_rotacion = crear_campo(campos, "Rotación al mes (%)", 0, 1, ROTACION_MENSUAL_EJEMPLO, 10, BLANCO)
    campo_costo = crear_campo(campos, "Costo por salida ($)", 0, 2, COSTO_POR_SALIDA, 10, BLANCO)
    campo_traslado = crear_campo(campos, "Renuncias por traslado (%)", 0, 3,
                                 PORCENTAJE_SALIDAS_POR_TRASLADO, 10, BLANCO)

    resultado_rotacion = tk.Label(caja_empresa, text="", bg=BLANCO, fg=TINTA, font=(FUENTE, 11),
                                  justify="left", wraplength=860)
    resultado_rotacion.pack(anchor="w")
    resultado_llegabien = tk.Label(caja_empresa, text="", bg=BLANCO, fg=VERDE, font=(FUENTE, 11, "bold"),
                                   justify="left", wraplength=860)
    resultado_llegabien.pack(anchor="w", pady=(6, 0))
    estado = tk.Label(caja_empresa, text="", bg=BLANCO, fg=ROJO, font=(FUENTE, 10, "bold"))
    estado.pack(anchor="w")

    def recalcular():
        try:
            empleados = int(convertir_numero(campo_empleados.get()))
            rotacion = convertir_numero(campo_rotacion.get())
            costo_salida = convertir_numero(campo_costo.get())
            porcentaje_traslado = convertir_numero(campo_traslado.get())
        except ValueError:
            estado.config(text="Escribe solo números en los datos de tu empresa.")
            return
        if empleados <= 0 or costo_salida <= 0 or not 0 <= rotacion <= 100 \
                or not 0 <= porcentaje_traslado <= 100:
            estado.config(text="Revisa: empleados y costo mayores a 0; porcentajes entre 0 y 100.")
            return
        estado.config(text="")

        costo = calcular_costo_rotacion(empleados, rotacion, costo_salida, porcentaje_traslado / 100)  # F4
        llegabien = calcular_costo_llegabien(empleados, PRECIO_POR_TRABAJADOR_MES, costo_salida)
        valor_costo.config(text=formato_pesos(costo["costo_traslado"]))
        resultado_rotacion.config(text=(
            f"Con {rotacion:g} % de rotación al mes se van {costo['salidas']} personas al año: "
            f"{formato_pesos(costo['costo_total'])} en total. Si {porcentaje_traslado:g} % de las "
            f"renuncias es por el traslado, son {costo['salidas_traslado']} renuncias y "
            f"{formato_pesos(costo['costo_traslado'])} al año."))
        renuncias = plural(llegabien["renuncias_para_pagarse"], "renuncia", "renuncias")
        resultado_llegabien.config(text=(
            f"LlegaBien para {empleados} empleados: {formato_pesos(llegabien['mensual'])} al mes "
            f"({formato_pesos(llegabien['anual'])} al año). Se paga con evitar {renuncias} al año."))

    recalcular()      # primer cálculo con los valores de ejemplo

    texto_pequeno(cuerpo, f"{FUENTE_COSTO_SALIDA} Empleados, rotación y % por traslado son ejemplos. "
                          f"Precio de LlegaBien: propuesta de ${PRECIO_POR_TRABAJADOR_MES} por trabajador "
                          "al mes. La regla de riesgo es del equipo (D3). Fuentes completas en "
                          "docs/FUENTES.md.").pack(anchor="w", pady=(10, 0))
    fila_de_botones(cuerpo, volver_menu, "Recalcular", recalcular)
    win.bind("<Return>", lambda evento: recalcular())
    return win
