"""Ventana 5 · Plan de acción: qué hacer para que la gente llegue a tiempo y con menos tráfico.

Acción 1: una ruta para la colonia con más riesgo (F4 y F6).
Acción 2: horarios escalonados en la hora con más retardos (F5).
"""
import tkinter as tk

from src.app.estilo import (BLANCO, FUENTE, GRIS, GRIS_BORDE, GRIS_FONDO, ROJO, TINTA, VERDE,
                            boton_primario, crear_campo, crear_lista, crear_ventana,
                            encabezado_seccion, fila_de_botones, linea, subtitulo, tarjeta,
                            texto_pequeno, titulo_grande)
from src.core.data_io import RUTA_EJEMPLO, RUTA_USUARIO, cargar_trabajadores, colonias_registradas
from src.core.datos_referencia import (COSTO_POR_SALIDA, COSTO_TRANSPORTE_POR_TRABAJADOR_ANIO,
                                       EMPLEADOS_EJEMPLO, FUENTE_ESCALONADO, FUENTE_TRANSPORTE,
                                       PORCENTAJE_SALIDAS_POR_TRASLADO, ROTACION_MENSUAL_EJEMPLO)
from src.core.logic import (calcular_costo_rotacion, colonias_con_mas_riesgo, convertir_numero,
                            estimar_costo_ruta, formato_pesos, hora_con_mas_retardos, mover_hora,
                            plural, resumir_colonia, resumir_plantilla, retardos_por_hora,
                            ruta_se_paga, salidas_de_colonia)


def dibujar_retardos(lienzo, promedios, hora_critica, ancho=420):
    """Barras con el promedio de retardos por hora de entrada. La hora crítica va en rojo."""
    x_inicio = 60
    mayor = max(promedios.values()) if promedios else 0
    largo_maximo = ancho - x_inicio - 50
    for i, (hora, valor) in enumerate(promedios.items()):
        y = 8 + i * 30
        largo = largo_maximo * valor / mayor if mayor else 0
        color = ROJO if hora == hora_critica else GRIS_BORDE
        lienzo.create_text(8, y + 10, text=hora, anchor="w", fill=TINTA, font=(FUENTE, 10, "bold"))
        lienzo.create_rectangle(x_inicio, y, x_inicio + largo, y + 20, fill=color, outline="")
        lienzo.create_text(x_inicio + largo + 8, y + 10, text=f"{valor:.1f}", anchor="w",
                           fill=TINTA, font=(FUENTE, 10))


def open_win_plan(parent):
    win, cuerpo, volver_menu = crear_ventana(parent, "Plan de acción", "Plan de acción  /  rutas y horarios",
                                             1000, 720)

    trabajadores = cargar_trabajadores([RUTA_EJEMPLO, RUTA_USUARIO])
    resumen = resumir_plantilla(trabajadores)

    titulo_grande(cuerpo, "Qué hacer ", "ahora.").pack(anchor="w")
    subtitulo(cuerpo, "Dos acciones para que tu gente llegue a tiempo y haya menos coches "
                      "en hora pico.").pack(anchor="w", pady=(2, 8))
    linea(cuerpo, VERDE, 2).pack(fill="x", pady=(0, 12))

    if resumen["total"] == 0:
        subtitulo(cuerpo, "Todavía no hay trabajadores. Registra algunos en la opción 2.").pack(anchor="w")
        fila_de_botones(cuerpo, volver_menu)
        return win

    # ================= Acción 1: una ruta =================
    caja_ruta = tarjeta(cuerpo)
    caja_ruta.pack(fill="x", padx=(0, 10))
    encabezado_seccion(caja_ruta, "1. Una ruta para la colonia con más riesgo", BLANCO).pack(anchor="w")

    # Colonias ordenadas: primero las que tienen más trabajadores en riesgo alto
    opciones = [colonia for colonia, _ in colonias_con_mas_riesgo(trabajadores, cuantas=50)]
    for colonia in colonias_registradas(trabajadores):      # luego las demás, en orden alfabético
        if colonia not in opciones:
            opciones.append(colonia)

    campos = tk.Frame(caja_ruta, bg=BLANCO)
    campos.pack(fill="x", pady=(4, 0))
    for columna in range(3):
        campos.columnconfigure(columna, weight=1)
    lista_colonia = crear_lista(campos, "Colonia", 0, 0, opciones, solo_lectura=True, fondo=BLANCO)
    lista_colonia.set(opciones[0])
    campo_ruta = crear_campo(campos, "Costo de la ruta al mes ($)", 0, 1, "", 12, BLANCO)
    campo_empleados = crear_campo(campos, "Empleados de la empresa", 0, 2, EMPLEADOS_EJEMPLO, 12, BLANCO)
    campo_rotacion = crear_campo(campos, "Rotación al mes (%)", 1, 0, ROTACION_MENSUAL_EJEMPLO, 12, BLANCO)
    campo_costo = crear_campo(campos, "Costo por salida ($)", 1, 1, COSTO_POR_SALIDA, 12, BLANCO)
    campo_traslado = crear_campo(campos, "Renuncias por traslado (%)", 1, 2,
                                 PORCENTAJE_SALIDAS_POR_TRASLADO, 12, BLANCO)

    datos_colonia = tk.Label(caja_ruta, text="", bg=BLANCO, fg=TINTA, font=(FUENTE, 11),
                             justify="left", wraplength=860)
    datos_colonia.pack(anchor="w", pady=(4, 0))
    impacto_trafico = tk.Label(caja_ruta, text="", bg=BLANCO, fg=VERDE, font=(FUENTE, 11, "bold"),
                               justify="left", wraplength=860)
    impacto_trafico.pack(anchor="w")
    resultado_ruta = tk.Label(caja_ruta, text="", bg=BLANCO, fg=TINTA, font=(FUENTE, 11),
                              justify="left", wraplength=860)
    resultado_ruta.pack(anchor="w", pady=(8, 0))
    veredicto = tk.Label(caja_ruta, text="", bg=BLANCO, font=(FUENTE, 12, "bold"))
    veredicto.pack(anchor="w")

    def calcular_ruta():
        colonia = lista_colonia.get()
        datos = resumir_colonia(trabajadores, colonia)
        try:
            costo_ruta = convertir_numero(campo_ruta.get())
            empleados = int(convertir_numero(campo_empleados.get()))
            rotacion = convertir_numero(campo_rotacion.get())
            costo_salida = convertir_numero(campo_costo.get())
            porcentaje_traslado = convertir_numero(campo_traslado.get())
        except ValueError:
            veredicto.config(text="Escribe solo números en los campos.", fg=ROJO)
            return
        if costo_ruta <= 0 or empleados <= 0 or costo_salida <= 0 \
                or not 0 <= rotacion <= 100 or not 0 <= porcentaje_traslado <= 100:
            veredicto.config(text="Revisa: costos y empleados mayores a 0; porcentajes entre 0 y 100.", fg=ROJO)
            return

        costo = calcular_costo_rotacion(empleados, rotacion, costo_salida, porcentaje_traslado / 100)  # F4
        salidas_colonia = salidas_de_colonia(costo["salidas_traslado"], datos["alto"], resumen["ALTO"])
        renuncias, conviene = ruta_se_paga(costo_ruta, costo_salida, salidas_colonia)                   # F6

        resultado_ruta.config(text=(
            f"La ruta cuesta {formato_pesos(costo_ruta * 12)} al año y se paga con evitar "
            f"{plural(renuncias, 'renuncia', 'renuncias')}. Tu empresa pierde unas "
            f"{costo['salidas_traslado']} personas al año por el traslado; de ellas, unas "
            f"{salidas_colonia} vendrían de {colonia} (según sus trabajadores en riesgo alto)."))
        if conviene:
            veredicto.config(text="Conviene: la ruta se paga sola.", fg=VERDE)
        else:
            veredicto.config(text="Todavía no conviene: prueba una camioneta más chica o juntar dos "
                                  "colonias cercanas en la misma ruta.", fg=ROJO)

    def elegir_colonia(evento=None):
        """Cuando cambia la colonia: muestra sus datos y pone un costo estimado de la ruta."""
        colonia = lista_colonia.get()
        datos = resumir_colonia(trabajadores, colonia)
        datos_colonia.config(text=f"{colonia}: {datos['total']} trabajadores · {datos['alto']} en riesgo "
                                  f"alto · {datos['en_vehiculo']} van en auto o moto.")
        impacto_trafico.config(text=f"Con una ruta, hasta {datos['en_vehiculo']} vehículos menos en hora "
                                    f"pico, y {datos['alto']} personas en riesgo alto con una opción directa.")
        campo_ruta.delete(0, "end")
        campo_ruta.insert(0, str(estimar_costo_ruta(datos["total"], COSTO_TRANSPORTE_POR_TRABAJADOR_ANIO)))
        calcular_ruta()

    lista_colonia.bind("<<ComboboxSelected>>", elegir_colonia)
    boton_primario(caja_ruta, "¿Se paga sola?", calcular_ruta).pack(anchor="w", pady=(10, 4))
    texto_pequeno(caja_ruta, f"El costo de la ruta es un estimado: {FUENTE_TRANSPORTE} "
                             "Pide la cotización real a un transportista y escríbela arriba.",
                  BLANCO, 860).pack(anchor="w")
    elegir_colonia()      # primer cálculo con la colonia de más riesgo

    # ================= Acción 2: horarios escalonados =================
    caja_horario = tarjeta(cuerpo)
    caja_horario.pack(fill="x", padx=(0, 10), pady=(12, 0))
    encabezado_seccion(caja_horario, "2. Horarios escalonados", BLANCO).pack(anchor="w")

    promedios = retardos_por_hora(trabajadores)
    hora, promedio_retardos = hora_con_mas_retardos(trabajadores)       # F5
    if hora == "--":
        tk.Label(caja_horario, text="Todavía no hay retardos registrados.", bg=BLANCO, fg=GRIS,
                 font=(FUENTE, 11)).pack(anchor="w")
    else:
        texto_pequeno(caja_horario, "Retardos al mes por persona, según su hora de entrada:",
                      BLANCO).pack(anchor="w", pady=(4, 0))
        lienzo = tk.Canvas(caja_horario, width=420, height=12 + 30 * len(promedios), bg=BLANCO,
                           highlightthickness=0)
        lienzo.pack(anchor="w", pady=(4, 6))
        dibujar_retardos(lienzo, promedios, hora)

        personas = 0
        for trabajador in trabajadores:
            if trabajador["hora_entrada"] == hora:
                personas += 1
        tk.Label(caja_horario, text=(f"La entrada de las {hora} junta más retardos: {promedio_retardos:.1f} "
                                     f"al mes por persona ({personas} trabajadores entran a esa hora)."),
                 bg=BLANCO, fg=TINTA, font=(FUENTE, 11), justify="left", wraplength=860).pack(anchor="w")
        tk.Label(caja_horario, text=(f"Prueba dividir ese grupo: una parte entra a las {mover_hora(hora, -30)} "
                                     f"y otra a las {mover_hora(hora, 30)}, para que no todos lleguen en "
                                     "la misma hora pico."),
                 bg=BLANCO, fg=VERDE, font=(FUENTE, 11, "bold"), justify="left",
                 wraplength=860).pack(anchor="w", pady=(4, 0))
        texto_pequeno(caja_horario, FUENTE_ESCALONADO, BLANCO, 860).pack(anchor="w", pady=(6, 0))

    fila_de_botones(cuerpo, volver_menu)
    return win
