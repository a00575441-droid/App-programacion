"""Ventana 2 · Registrar trabajador: captura cómo llega a trabajar (usa F1 y F8)."""
import tkinter as tk

from src.app.estilo import (BLANCO, COLOR_RIESGO, FUENTE, FUENTE_TITULO, GRIS, GRIS_FONDO, ROJO,
                            VERDE, crear_campo, crear_lista, crear_ventana, fila_de_botones,
                            linea, subtitulo, tarjeta, texto_pequeno, titulo_grande)
from src.core.data_io import (RUTA_EJEMPLO, RUTA_USUARIO, cargar_trabajadores,
                              colonias_registradas, guardar_trabajador, numero_registrado)
from src.core.logic import REGLA_RIESGO, clasificar_riesgo, validar_hora, validar_trabajador

HORAS_COMUNES = ["06:00", "07:00", "08:00", "09:00", "14:00", "15:00", "22:00"]
MEDIOS = ["Camión", "Auto", "Moto", "Transporte de la empresa", "Bicicleta", "Caminando"]


def open_win_form(parent):
    win, cuerpo, volver_menu = crear_ventana(parent, "Registrar trabajador",
                                             "Registrar  /  nuevo trabajador", 880, 640)

    titulo_grande(cuerpo, "Registra a ", "un trabajador.").pack(anchor="w")
    subtitulo(cuerpo, "Así sabremos cómo llega a trabajar. Solo pedimos la colonia, "
                      "no el domicilio.").pack(anchor="w", pady=(2, 10))
    linea(cuerpo, VERDE, 2).pack(fill="x", pady=(0, 8))

    # ---------- Formulario en dos columnas ----------
    formulario = tk.Frame(cuerpo, bg=GRIS_FONDO)
    formulario.pack(fill="x")
    formulario.columnconfigure(0, weight=1)
    formulario.columnconfigure(1, weight=1)

    colonias = colonias_registradas(cargar_trabajadores([RUTA_EJEMPLO, RUTA_USUARIO]))
    campo_numero = crear_campo(formulario, "Número de empleado", 0, 0)
    lista_colonia = crear_lista(formulario, "Colonia (elige o escribe)", 1, 0, colonias)
    lista_hora = crear_lista(formulario, "Hora de entrada (HH:MM)", 2, 0, HORAS_COMUNES)
    lista_medio = crear_lista(formulario, "Medio de transporte", 3, 0, MEDIOS, solo_lectura=True)
    campo_minutos = crear_campo(formulario, "Minutos de traslado (solo ida)", 0, 1)
    campo_transbordos = crear_campo(formulario, "Transbordos (cambios de camión)", 1, 1, 0)
    campo_retardos = crear_campo(formulario, "Retardos en el último mes", 2, 1, 0)

    # ---------- Resultado: el riesgo del trabajador que se acaba de guardar ----------
    caja = tarjeta(formulario)
    caja.grid(row=3, column=1, sticky="ew", padx=(0, 16), pady=6)
    tk.Label(caja, text="Riesgo de traslado", bg=BLANCO, fg=GRIS, font=(FUENTE, 9)).pack(anchor="w")
    etiqueta_riesgo = tk.Label(caja, text="—", bg=BLANCO, fg=GRIS, font=(FUENTE_TITULO, 18))
    etiqueta_riesgo.pack(anchor="w")
    etiqueta_regla = tk.Label(caja, text="Aparece al guardar", bg=BLANCO, fg=GRIS, font=(FUENTE, 9))
    etiqueta_regla.pack(anchor="w")

    mensaje = tk.Label(cuerpo, text="", bg=GRIS_FONDO, fg=GRIS, font=(FUENTE, 10, "bold"),
                       justify="left", wraplength=800)
    mensaje.pack(anchor="w", pady=(8, 0))

    def avisar(texto, color):
        mensaje.config(text=texto, fg=color)

    def guardar():
        numero = campo_numero.get().strip()
        colonia = lista_colonia.get().strip()
        for conocida in colonias:                 # "las joyas" se guarda igual que "Las Joyas"
            if conocida.lower() == colonia.lower():
                colonia = conocida
        hora = lista_hora.get().strip()
        medio = lista_medio.get().strip()

        # 1) Revisar que no falte nada y que el número no esté repetido
        if not numero or not colonia or not medio:
            avisar("Completa número de empleado, colonia y medio de transporte.", ROJO)
            return
        if numero_registrado(cargar_trabajadores([RUTA_EJEMPLO, RUTA_USUARIO]), numero):
            avisar(f"Ya hay un trabajador con el número {numero}. Usa otro número.", ROJO)
            return
        if not validar_hora(hora):
            avisar("Escribe la hora como HH:MM, por ejemplo 07:00.", ROJO)
            return
        # 2) Revisar los números con F8
        es_valido, texto = validar_trabajador(campo_minutos.get(), campo_transbordos.get(),
                                              campo_retardos.get())
        if not es_valido:
            avisar(texto, ROJO)
            return

        trabajador = {
            "numero": numero, "colonia": colonia, "hora_entrada": hora, "medio": medio,
            "minutos": int(campo_minutos.get()), "transbordos": int(campo_transbordos.get()),
            "retardos": int(campo_retardos.get()),
        }
        # 3) Guardar en el CSV (si el archivo está abierto en Excel, puede fallar)
        try:
            guardar_trabajador(RUTA_USUARIO, trabajador)
        except OSError as error:
            avisar(f"No se pudo guardar. ¿Está abierto el archivo en Excel? ({error})", ROJO)
            return

        # 4) Mostrar el riesgo con F1
        nivel = clasificar_riesgo(trabajador["minutos"], trabajador["transbordos"])
        etiqueta_riesgo.config(text=nivel, fg=COLOR_RIESGO[nivel])
        etiqueta_regla.config(text=REGLA_RIESGO[nivel])
        avisar(f"Listo: {numero} quedó guardado. Ya aparece en Plantilla y en Diagnóstico.", VERDE)

        # 5) Limpiar para capturar al siguiente
        campo_numero.delete(0, "end")
        campo_minutos.delete(0, "end")
        for campo in (campo_transbordos, campo_retardos):
            campo.delete(0, "end")
            campo.insert(0, "0")
        campo_numero.focus_set()

    texto_pequeno(cuerpo, f"Se guarda en data/{RUTA_USUARIO.name}. Regla de riesgo de LlegaBien: "
                          f"ALTO = {REGLA_RIESGO['ALTO']}; MEDIO = {REGLA_RIESGO['MEDIO']}.").pack(anchor="w", pady=(6, 0))
    fila_de_botones(cuerpo, volver_menu, "Guardar trabajador", guardar)
    win.bind("<Return>", lambda evento: guardar())     # Enter también guarda
    campo_numero.focus_set()
    return win
