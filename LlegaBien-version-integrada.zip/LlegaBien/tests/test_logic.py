"""Pruebas de la lógica de LlegaBien con los casos del D3.

Cómo correrlas (desde la carpeta principal del proyecto):
    python -m unittest tests.test_logic -v
"""
import tempfile
import unittest
from pathlib import Path

from src.core.data_io import (cargar_trabajadores, eliminar_trabajador, guardar_trabajador,
                              numero_registrado)
from src.core.logic import (
    calcular_costo_llegabien, calcular_costo_rotacion, clasificar_riesgo,
    colonias_con_mas_riesgo, convertir_numero, estimar_costo_ruta, formato_pesos,
    generar_alertas, hora_con_mas_retardos, mover_hora, plural, promedio, resumir_colonia,
    resumir_plantilla, ruta_se_paga, salidas_de_colonia, validar_hora, validar_trabajador,
)


def trabajador(colonia="A", minutos=10, transbordos=0, hora="07:00", retardos=0, medio="Camión"):
    """Crea un trabajador de prueba con valores por defecto."""
    return {"numero": "X", "colonia": colonia, "hora_entrada": hora, "medio": medio,
            "minutos": minutos, "transbordos": transbordos, "retardos": retardos}


class PruebasRiesgo(unittest.TestCase):
    def test_f1_casos_del_d3(self):
        self.assertEqual(clasificar_riesgo(65, 0), "ALTO")
        self.assertEqual(clasificar_riesgo(45, 1), "MEDIO")
        self.assertEqual(clasificar_riesgo(20, 0), "BAJO")
        self.assertEqual(clasificar_riesgo(20, 2), "ALTO")

    def test_f1_casos_limite(self):
        self.assertEqual(clasificar_riesgo(60, 0), "ALTO")
        self.assertEqual(clasificar_riesgo(59, 0), "MEDIO")
        self.assertEqual(clasificar_riesgo(30, 0), "MEDIO")
        self.assertEqual(clasificar_riesgo(29, 0), "BAJO")

    def test_f2_resumen(self):
        plantilla = [trabajador(minutos=m) for m in (70, 40, 10, 15)]
        resumen = resumir_plantilla(plantilla)
        self.assertEqual((resumen["ALTO"], resumen["MEDIO"], resumen["BAJO"]), (1, 1, 2))
        self.assertEqual(resumen["porcentaje_largos"], 25.0)

    def test_f2_lista_vacia(self):
        self.assertEqual(resumir_plantilla([])["porcentaje_largos"], 0.0)

    def test_f3_top_colonias(self):
        plantilla = ([trabajador("A", 70)] * 3 + [trabajador("B", 70)] * 5
                     + [trabajador("C", 70)] + [trabajador("D", 10)] * 4)
        self.assertEqual(colonias_con_mas_riesgo(plantilla), [("B", 5), ("A", 3), ("C", 1)])


class PruebasDinero(unittest.TestCase):
    def test_f4_caso_del_d3(self):
        resultado = calcular_costo_rotacion(120, 6, 47_000, 0.2)
        self.assertEqual(resultado["salidas"], 86)
        self.assertEqual(resultado["costo_total"], 4_042_000)
        self.assertEqual(resultado["salidas_traslado"], 17)
        self.assertEqual(resultado["costo_traslado"], 799_000)

    def test_f6_caso_del_d3(self):
        self.assertEqual(ruta_se_paga(20_000, 47_000, 17), (6, True))
        self.assertEqual(ruta_se_paga(20_000, 47_000, 5), (6, False))

    def test_precio_llegabien_200_empleados(self):
        resultado = calcular_costo_llegabien(200, 30, 47_000)
        self.assertEqual(resultado["mensual"], 6_000)
        self.assertEqual(resultado["anual"], 72_000)
        self.assertEqual(resultado["renuncias_para_pagarse"], 2)

    def test_estimar_ruta(self):
        self.assertEqual(estimar_costo_ruta(12, 25_000), 25_000)

    def test_salidas_de_colonia(self):
        self.assertEqual(salidas_de_colonia(24, 11, 16), 16)
        self.assertEqual(salidas_de_colonia(24, 0, 0), 0)

    def test_formato_pesos(self):
        self.assertEqual(formato_pesos(4_042_000), "$4,042,000")


class PruebasHorariosYAlertas(unittest.TestCase):
    def test_f5_caso_del_d3(self):
        plantilla = [trabajador(hora="07:00", retardos=3), trabajador(hora="07:00", retardos=1),
                     trabajador(hora="08:00", retardos=0), trabajador(hora="08:00", retardos=1)]
        self.assertEqual(hora_con_mas_retardos(plantilla), ("07:00", 2.0))

    def test_f5_sin_retardos(self):
        self.assertEqual(hora_con_mas_retardos([]), ("--", 0.0))

    def test_f7_caso_del_d3(self):
        alertas = generar_alertas(25.0, [("A", 11), ("B", 4)])
        self.assertEqual(len(alertas), 2)
        self.assertIn("A: 11 trabajadores", alertas[1])

    def test_mover_hora(self):
        self.assertEqual(mover_hora("07:00", -30), "06:30")
        self.assertEqual(mover_hora("07:00", 30), "07:30")
        self.assertEqual(mover_hora("00:15", -30), "23:45")

    def test_resumir_colonia(self):
        plantilla = [trabajador("A", 70, medio="Auto"), trabajador("A", 20, medio="Moto"),
                     trabajador("A", 80), trabajador("B", 90, medio="Auto")]
        self.assertEqual(resumir_colonia(plantilla, "A"), {"total": 3, "alto": 2, "en_vehiculo": 2})


class PruebasValidacion(unittest.TestCase):
    def test_f8(self):
        self.assertEqual(validar_trabajador("45", "1", "2"), (True, "Datos correctos"))
        self.assertFalse(validar_trabajador("abc", "1", "2")[0])
        self.assertFalse(validar_trabajador("45", "-1", "2")[0])
        self.assertFalse(validar_trabajador("", "1", "2")[0])

    def test_validar_hora(self):
        self.assertTrue(validar_hora("07:00"))
        self.assertFalse(validar_hora("7:00"))
        self.assertFalse(validar_hora("25:00"))
        self.assertFalse(validar_hora("07-00"))

    def test_convertir_numero(self):
        self.assertEqual(convertir_numero("$47,000"), 47000.0)
        self.assertEqual(convertir_numero(" 5 % "), 5.0)
        with self.assertRaises(ValueError):
            convertir_numero("cinco")

    def test_plural(self):
        self.assertEqual(plural(1, "renuncia", "renuncias"), "1 renuncia")
        self.assertEqual(plural(3, "renuncia", "renuncias"), "3 renuncias")

    def test_promedio(self):
        self.assertEqual(promedio([10, 20, 30]), 20)
        self.assertEqual(promedio([]), 0.0)


class PruebasArchivos(unittest.TestCase):
    """Guardar y eliminar trabajadores en un CSV temporal (no toca los datos reales)."""

    def setUp(self):
        self.carpeta = tempfile.TemporaryDirectory()
        self.ruta = Path(self.carpeta.name) / "prueba.csv"
        for numero in ("001", "A2", "A3"):
            guardar_trabajador(self.ruta, trabajador(minutos=45) | {"numero": numero})

    def tearDown(self):
        self.carpeta.cleanup()

    def test_eliminar_uno(self):
        self.assertTrue(eliminar_trabajador([self.ruta], "A2"))
        numeros = [t["numero"] for t in cargar_trabajadores([self.ruta])]
        self.assertEqual(numeros, ["001", "A3"])        # "001" conserva sus ceros
        self.assertTrue(self.ruta.read_text(encoding="utf-8").startswith("numero,colonia"))

    def test_eliminar_inexistente(self):
        self.assertFalse(eliminar_trabajador([self.ruta], "Z9"))
        self.assertEqual(len(cargar_trabajadores([self.ruta])), 3)

    def test_numero_repetido(self):
        plantilla = cargar_trabajadores([self.ruta])
        self.assertTrue(numero_registrado(plantilla, " a2 "))
        self.assertFalse(numero_registrado(plantilla, "A4"))


if __name__ == "__main__":
    unittest.main()
