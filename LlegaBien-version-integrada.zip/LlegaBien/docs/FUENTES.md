# Fuentes de los datos de LlegaBien

Todos los números que muestra la app están en `src/core/datos_referencia.py`. Aquí están sus fuentes en formato APA 7.

## Qué dato sale de cada fuente

| Dato en la app | Valor | Tipo | Fuente |
|---|---|---|---|
| Costo de cada persona que rota | $47,000 | Dato publicado | Apli, citado en Mendoza Rojas (2022) |
| Costo de una renuncia antes de 3 meses | $17,431 | Dato publicado (referencia baja) | Brivé Soluciones, citado en Expansión (2025) |
| Gasto en transporte de personal | $20,000 a $30,000 por empleado al año | Dato publicado (de 2020) | Milenio (2020), citado en Mexico Business News (s.f.) |
| Horas perdidas por el tráfico en León | 88 al año (132 en transporte público) | Dato publicado | IMCO, citado en Líder Empresarial (2026) |
| Apoyo para transporte entre los beneficios más valorados | 41 % de los trabajadores | Dato publicado | Pluxee, citado en Publimetro (2026a) |
| Ahorro con horarios escalonados | Hasta 30 minutos por trayecto | Dato publicado (Nuevo León) | Publimetro (2026b) |
| Rotación mensual | 5 % | **Ejemplo** | Referencia: 6 a 10 % al mes en empresas nuevas del Bajío (Hernández, 2017) |
| Renuncias que se deben al traslado | 20 % | **Supuesto del equipo** | Cada empresa lo ajusta con sus entrevistas de salida |
| Empleados de la empresa | 200 | **Ejemplo** | Para la demostración |
| Trabajadores E001 a E036 | — | **Datos ficticios** | Para la demostración |
| Regla de riesgo (60 / 30 minutos; 2 / 1 transbordos) | — | **Regla del equipo** | D3 · MVP Blueprint |
| Precio de LlegaBien | $30 por trabajador al mes | **Propuesta del equipo** | Se validará con empresarios en la feria |

**Cambio respecto a la versión anterior del Inicio:** se quitó el dato "47 % de los empleadores reconoce el traslado como causa de renuncia (OCC Mundial et al., 2023)" porque no se encontró en la fuente. El 47 % del estudio de OCC Mundial se refiere a otra cosa (renunciar por exceso de trabajo o monotonía).

## Referencias

Expansión. (2025, 27 de enero). *Malos jefes, altos costos: el impacto oculto de la rotación laboral en México*. https://expansion.mx/carrera/2025/01/27/malos-jefes-altos-costos-impacto-rotacion-laboral-mexico

Hernández, R. (2017, 8 de junio). Alta rotación laboral pega a empresas japonesas y alemanas en el Bajío. *El Financiero*. https://www.elfinanciero.com.mx/bajio/alta-rotacion-laboral-pega-a-empresas-japonesas-y-alemanas-en-el-bajio/

Líder Empresarial. (2026). *Tráfico en León cuesta más de 3 mil 364 millones de pesos al año: IMCO*. https://www.liderempresarial.com/trafico-en-leon-cuesta-mas-de-3-mil-364-millones-de-pesos-al-ano-imco/

Mendoza Rojas, M. (2022, 17 de febrero). ¡Fallidas! 40% de las contrataciones de empresas que operan en México. *Publimetro*. https://www.publimetro.com.mx/noticias/2022/02/17/empresas-fallidas-40-por-ciento-de-contrataciones-en-mexico/

Mexico Business News. (s.f.). *Mexican manufacturers face rising invisible shuttle costs*. https://mexicobusiness.news/logistics/news/mexican-manufacturers-face-rising-invisible-shuttle-costs

Publimetro. (2026a, 6 de agosto). *Volver a la oficina sale caro: empleados gastan más y el home office retrocede*. https://www.publimetro.com.mx/noticias/2026/08/06/volver-a-la-oficina-sale-caro-empleados-gastan-mas-y-el-home-office-retrocede/

Publimetro. (2026b, 10 de septiembre). *Horarios escalonados permiten ahorrar hasta 30 minutos por trayecto; ya suman 300 empresas en NL*. https://www.publimetro.com.mx/nuevo-leon/2026/09/10/horarios-escalonados-permiten-ahorrar-hasta-30-minutos-por-trayecto-ya-suman-300-empresas-en-nl/
