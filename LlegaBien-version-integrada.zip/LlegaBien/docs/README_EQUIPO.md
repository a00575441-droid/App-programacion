# Documentación del equipo

Coloca aquí D1, D2, D3, decisiones técnicas, plan de pruebas y evidencia de iteraciones.

## Cambios de la versión rediseñada (noviembre 2026)

- Todas las ventanas usan el estilo de la pantalla de Inicio (`src/app/estilo.py`).
- Se quitaron Fuente de datos y Clima; el menú queda con 6 opciones y el Asistente con IA es la 6.
- Nueva ventana **Plan de acción**: ruta para la colonia con más riesgo (F6) y horarios escalonados (F5).
- **Diagnóstico** muestra el costo en pesos de las renuncias por traslado y el precio de LlegaBien.
- Inicio: se corrigió `Path(_file_)` por `Path(__file__)` y se cambió un dato que no tenía fuente comprobable (ver `docs/FUENTES.md`).
- Asistente con IA: solo cambió el diseño; `consultar`, `revisar_respuesta` y `enviar` son las mismas.
- Las funciones F1 a F8 están en `src/core/logic.py` y tienen pruebas en `tests/test_logic.py`.
- Versión 2: botón **Eliminar trabajador** en Plantilla (pide confirmación) y Registrar ya no acepta números de empleado repetidos.
- Versión 3: la mascota de LlegaBien aparece en el Asistente con IA con un saludo (`assets/mascota_chat.png`). La lógica de la IA no cambió.
