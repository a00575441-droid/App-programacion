# LlegaBien — Diagnóstico del traslado de tu plantilla

Proyecto Integrador TC1038 · Movilidad Inteligente · Tecnológico de Monterrey, Campus León.

LlegaBien le muestra a una empresa **cuánto le cuestan las renuncias por traslado**, qué trabajadores tienen un traslado de riesgo y qué hacer (rutas y horarios escalonados) para que su gente llegue a tiempo y haya menos coches en hora pico.

## Cómo abrirla en VS Code

1. Descomprime el zip y abre la carpeta **LlegaBien** completa en VS Code (*File → Open Folder*).
2. Instala la única librería externa (la usa el Asistente con IA):
   ```
   python -m pip install -r requirements.txt
   ```
3. Abre `src/app/main.py` y presiona ▷, o en *Run and Debug* elige **LlegaBien (app)** y presiona F5.
4. Para correr las pruebas: elige **LlegaBien (pruebas)**, o escribe en la terminal:
   ```
   python -m unittest tests.test_logic -v
   ```

## Las 6 opciones del menú

| # | Ventana | Archivo | Funciones que usa |
|---|---|---|---|
| 1 | Inicio | `src/app/win_home.py` + `inicio_llegabien.png` | — |
| 2 | Registrar trabajador | `src/app/win_form.py` | F1, F8 |
| 3 | Plantilla (también para **eliminar** trabajadores) | `src/app/win_table.py` | F1, F2 |
| 4 | Diagnóstico (el costo en pesos) | `src/app/win_dashboard.py` | F2, F3, F4, F5, F7 |
| 5 | Plan de acción (rutas y horarios) | `src/app/win_plan.py` | F4, F5, F6 |
| 6 | Asistente con IA | `src/app/win_ia.py` | — |

Se quitaron las ventanas de Fuente de datos y Clima.

## Dónde está cada cosa

- `src/core/logic.py`: las funciones F1 a F8 del D3 y las de apoyo (todos los cálculos).
- `src/core/datos_referencia.py`: **todos los números de la app y de dónde salen.**
- `src/core/data_io.py`: leer y guardar los CSV.
- `src/app/estilo.py`: colores, letras, encabezado y botones con el estilo del Inicio.
- `data/trabajadores_ejemplo.csv`: 36 trabajadores ficticios para la demostración.
- `data/trabajadores_usuario.csv`: se crea solo cuando registras a alguien.
- `docs/FUENTES.md`: referencias en APA 7.
- `tests/test_logic.py`: 24 pruebas con los casos del D3 y de guardar/eliminar.

## Cómo eliminar a un trabajador

En **Plantilla**, haz clic en su renglón y presiona **Eliminar trabajador** (o la tecla Supr). La app pregunta "¿Seguro?" antes de borrar, porque no se puede deshacer.

## Modelo de negocio

Mensualidad de **$30 por trabajador** (propuesta para validar en la feria). Para una empresa de 200 trabajadores son $6,000 al mes; con un costo de $47,000 por cada persona que rota, se paga con evitar 2 renuncias al año.
