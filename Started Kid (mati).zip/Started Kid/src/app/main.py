"""Menú principal de LlegaBien — TC1038 Movilidad Inteligente."""
from pathlib import Path
import sys
import tkinter as tk

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.app.win_home import open_win_home
from src.app.win_form import open_win_form
from src.app.win_table import open_win_table
from src.app.win_dashboard import open_win_dashboard
from src.app.win_external import open_win_external
from src.app.win_canvas import open_win_canvas      # NUEVO: ventana de la API (Open-Meteo) con gráficas
from src.app.win_ia import open_win_ia              # CAMBIO 1 (IA): trae la ventana del asistente con IA

# ---------- Paleta de LlegaBien (sacada del logo) ----------
VERDE = "#01847D"
VERDE_OSCURO = "#016A64"
VERDE_CLARO = "#E2F2EF"
BLANCO = "#FFFFFF"
GRIS_FONDO = "#F0F3F2"
GRIS_BORDE = "#DCE2E0"
GRIS_OSCURO = "#2B3332"
GRIS = "#56605E"
GRIS_SUAVE = "#8A9491"
FUENTE = "Segoe UI"

# Carpeta donde están el logo y los íconos (src/app/assets)
ASSETS = Path(__file__).resolve().parent / "assets"


def cargar_imagen(nombre_archivo):
    """Abre un PNG de la carpeta assets.
    Si el archivo no existe, regresa None en lugar de detener la app."""
    try:
        return tk.PhotoImage(file=str(ASSETS / nombre_archivo))
    except tk.TclError:
        print("Aviso: no se encontró", ASSETS / nombre_archivo)
        return None


def crear_tarjeta(contenedor, raiz, numero, titulo, descripcion, icono, flecha, funcion, destacada):
    """Crea una tarjeta blanca con ícono, número, título, descripción y flecha.
    Al dar clic en cualquier parte de la tarjeta se abre la ventana de 'funcion'."""
    color_borde = VERDE if destacada else GRIS_BORDE
    grosor_borde = 2 if destacada else 1

    # El borde se dibuja con highlightthickness (grosor) y highlightbackground (color)
    tarjeta = tk.Frame(contenedor, bg=BLANCO, padx=14, pady=10,
                       highlightthickness=grosor_borde, highlightbackground=color_borde)
    tarjeta.pack(fill="x", pady=5)
    tarjeta.columnconfigure(2, weight=1)   # la columna del título se estira

    # Columna 0: ícono (ocupa los 2 renglones). Si no hay imagen, un cuadro verde claro
    if icono is not None:
        tk.Label(tarjeta, image=icono, bg=BLANCO).grid(row=0, column=0, rowspan=2, padx=(0, 14))
    else:
        tk.Label(tarjeta, text="", bg=VERDE_CLARO, width=4, height=2).grid(row=0, column=0, rowspan=2, padx=(0, 14))
    # Renglón 0: número verde + título
    tk.Label(tarjeta, text=numero, bg=BLANCO, fg=VERDE,
             font=(FUENTE, 10, "bold")).grid(row=0, column=1, sticky="w", padx=(0, 6))
    tk.Label(tarjeta, text=titulo, bg=BLANCO, fg=GRIS_OSCURO,
             font=(FUENTE, 13, "bold")).grid(row=0, column=2, sticky="w")
    # Renglón 1: descripción gris (ocupa las columnas 1 y 2)
    tk.Label(tarjeta, text=descripcion, bg=BLANCO, fg=GRIS,
             font=(FUENTE, 10)).grid(row=1, column=1, columnspan=2, sticky="w")
    # Columna 3: flecha a la derecha. Si no hay imagen, el símbolo ›
    if flecha is not None:
        tk.Label(tarjeta, image=flecha, bg=BLANCO).grid(row=0, column=3, rowspan=2, padx=(10, 0))
    else:
        tk.Label(tarjeta, text="›", bg=BLANCO, fg=GRIS_SUAVE,
                 font=(FUENTE, 18)).grid(row=0, column=3, rowspan=2, padx=(10, 0))

    # La tarjeta y todo lo que tiene adentro responden al mouse
    widgets = [tarjeta] + tarjeta.winfo_children()
    for widget in widgets:
        widget.configure(cursor="hand2")                                   # manita
        widget.bind("<Button-1>", lambda evento: funcion(raiz))             # clic: abre la ventana
        widget.bind("<Enter>", lambda evento: tarjeta.configure(highlightbackground=VERDE))
        widget.bind("<Leave>", lambda evento: tarjeta.configure(highlightbackground=color_borde))


def main():
    root = tk.Tk()
    root.title("LlegaBien")
    root.minsize(720, 0)          # ancho mínimo; el alto se ajusta solo al contenido
    root.configure(bg=GRIS_FONDO)

    # Las imágenes se guardan en root para que Python no las borre
    root.imagenes = {
        "icono": cargar_imagen("icono_llegabien.png"),
        "logo": cargar_imagen("logo_llegabien.png"),
        "flecha": cargar_imagen("flecha.png"),
        "salir": cargar_imagen("ic_salir.png"),
        "inicio": cargar_imagen("ic_inicio.png"),
        "registrar": cargar_imagen("ic_registrar.png"),
        "tabla": cargar_imagen("ic_tabla.png"),
        "diagnostico": cargar_imagen("ic_diagnostico_destacado.png"),
        "fuente": cargar_imagen("ic_fuente.png"),
        "clima": cargar_imagen("ic_clima.png"),      # NUEVO: si aún no existe el PNG, se muestra el cuadro verde claro
        "ia": cargar_imagen("ic_ia.png"),            # CAMBIO 2 (IA): ícono de la tarjeta 7; sin PNG sale el cuadro verde claro
    }
    if root.imagenes["icono"] is not None:
        root.iconphoto(True, root.imagenes["icono"])   # ícono de la barra de la ventana

    contenido = tk.Frame(root, bg=GRIS_FONDO, padx=30, pady=22)
    contenido.pack(fill="both", expand=True)

    # ---------- Encabezado: logo a la izquierda, etiqueta a la derecha ----------
    encabezado = tk.Frame(contenido, bg=GRIS_FONDO)
    encabezado.pack(fill="x")
    if root.imagenes["logo"] is not None:
        tk.Label(encabezado, image=root.imagenes["logo"], bg=GRIS_FONDO).pack(side="left")
    else:   # sin imagen: el nombre escrito
        tk.Label(encabezado, text="LlegaBien", bg=GRIS_FONDO, fg=GRIS_OSCURO,
                 font=(FUENTE, 20, "bold")).pack(side="left")
    tk.Label(encabezado, text="Menú principal", bg=VERDE_CLARO, fg=VERDE_OSCURO,
             font=(FUENTE, 10, "bold"), padx=14, pady=5).pack(side="right")

    # ---------- Título y subtítulo ----------
    tk.Label(contenido, text="¿Qué quieres hacer hoy?", bg=GRIS_FONDO, fg=GRIS_OSCURO,
             font=(FUENTE, 22, "bold")).pack(anchor="w", pady=(22, 0))
    tk.Label(contenido, text="Diagnóstico del traslado de tu plantilla. Elige una opción.",
             bg=GRIS_FONDO, fg=GRIS, font=(FUENTE, 11)).pack(anchor="w", pady=(2, 14))

    # ---------- Tarjetas: (número, título, descripción, ícono, función, destacada) ----------
    opciones = [
        ("1", "Inicio", "Problema, usuario y propuesta", "inicio", open_win_home, False),
        ("2", "Registrar trabajador", "Captura cómo llega cada trabajador", "registrar", open_win_form, False),
        ("3", "Datos de la plantilla", "Tabla con el riesgo de cada trabajador", "tabla", open_win_table, False),
        ("4", "Diagnóstico", "Semáforo, colonias, alertas y costo de la rotación", "diagnostico", open_win_dashboard, False),
        ("5", "Fuente de datos", "De dónde salen los datos", "fuente", open_win_external, False),
        ("6", "Clima en LP, Mich", "Temperatura por hora desde la API de Open-Meteo", "clima", open_win_canvas, False),   # NUEVO
        ("7", "Asistente con IA", "Pregúntale lo que quieras a la IA (OpenRouter)", "ia", open_win_ia, False),   # CAMBIO 3 (IA)
    ]
    for numero, titulo, descripcion, icono, funcion, destacada in opciones:
        crear_tarjeta(contenido, root, numero, titulo, descripcion, root.imagenes[icono],
                      root.imagenes["flecha"], funcion, destacada)

    # ---------- Pie: botón Salir y texto ----------
    pie = tk.Frame(contenido, bg=GRIS_FONDO)
    pie.pack(fill="x", pady=(16, 0))
    borde_salir = tk.Frame(pie, bg=VERDE, padx=2, pady=2)   # marco verde = borde del botón
    borde_salir.pack(side="left")
    # Si falta la imagen, image=None hace que el botón solo muestre el texto
    tk.Button(borde_salir, text="  Salir", image=root.imagenes["salir"], compound="left",
              bg=BLANCO, fg=VERDE_OSCURO, activebackground=VERDE_CLARO, activeforeground=VERDE_OSCURO,
              font=(FUENTE, 11, "bold"), relief="flat", bd=0, padx=16, pady=6, cursor="hand2",
              command=root.destroy).pack()
    tk.Label(pie, text="Movilidad laboral · León, Guanajuato", bg=GRIS_FONDO, fg=GRIS_SUAVE,
             font=(FUENTE, 10)).pack(side="right")

    root.mainloop()


if __name__ == "__main__":
    main()