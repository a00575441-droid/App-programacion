"""Ventana Tkinter que consulta una IA mediante OpenRouter."""

import queue                                    # "buzón" para pasar el resultado entre hilos
import threading                                # para consultar sin congelar la ventana
import tkinter as tk
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText   # caja de texto con barra de scroll

import requests                                 # librería para hacer peticiones por internet

URL = "https://openrouter.ai/api/v1/chat/completions"   # a dónde se manda la pregunta
MODELO = "nvidia/nemotron-3.5-lightning:free"            # qué IA contesta (gratis)


def open_win_ia(parent):
    """Abre una ventana para enviar preguntas y visualizar respuestas."""
    # ---------- Ventana secundaria (igual que en win_form.py) ----------
    win = tk.Toplevel(parent)
    win.title("Mi primera aplicación con IA")
    win.geometry("650x520")

    frm = ttk.Frame(win, padding=16)
    frm.pack(fill="both", expand=True)

    # ---------- Controles: crear y colocar ----------
    ttk.Label(frm, text="API Key de OpenRouter:").pack(anchor="w")
    campo_clave = ttk.Entry(frm, show="*")              # show="*" oculta la clave
    campo_clave.pack(fill="x", pady=(4, 12))

    ttk.Label(frm, text="Escribe tu pregunta:").pack(anchor="w")
    campo_pregunta = ScrolledText(frm, height=4, wrap="word")
    campo_pregunta.pack(fill="x", pady=(4, 12))

    ttk.Label(frm, text="Respuesta de la IA:").pack(anchor="w")
    campo_respuesta = ScrolledText(frm, height=12, wrap="word")
    campo_respuesta.pack(fill="both", expand=True, pady=(4, 8))

    estado = ttk.Label(frm, text="Listo para preguntar")   # mensajito de abajo
    estado.pack(anchor="w")
    resultados = queue.Queue()                             # el buzón

    def consultar(api_key, pregunta):
        """Ejecuta la petición HTTP fuera del hilo de la interfaz."""
        try:
            # PROCESO: manda la pregunta a OpenRouter
            respuesta = requests.post(
                URL,                                         # la dirección
                headers={
                    "Authorization": f"Bearer {api_key}",    # tu credencial
                    "Content-Type": "application/json",
                },
                json={                                       # el pedido: un diccionario
                    "model": MODELO,
                    "messages": [{"role": "user", "content": pregunta}],
                    "max_tokens": 1000,                      # largo máximo de la respuesta
                },
                timeout=120,                                 # espera máximo 120 segundos
            )
            respuesta.raise_for_status()                     # si hubo error (401, 429...), salta al except
            datos = respuesta.json()                         # SALIDA: convierte la respuesta en diccionario
            texto = datos["choices"][0]["message"]["content"]   # "abre las cajas" hasta llegar al texto
            resultados.put(("ok", texto or "(El modelo no devolvió texto)"))
        except requests.exceptions.Timeout:
            resultados.put(("error", "Se agotó el tiempo de espera."))
        except requests.exceptions.HTTPError as error:
            codigo = error.response.status_code if error.response is not None else "desconocido"
            resultados.put(("error", f"OpenRouter devolvió HTTP {codigo}."))
        except requests.exceptions.RequestException as error:
            resultados.put(("error", f"No se pudo conectar: {error}"))
        except (ValueError, KeyError, IndexError, TypeError):
            resultados.put(("error", "La respuesta de la API no tiene el formato esperado."))

    def revisar_respuesta():
        """Actualiza los widgets desde el hilo principal de Tkinter."""
        if not win.winfo_exists():                 # si ya cerraron la ventana, no hace nada
            return
        try:
            tipo, texto = resultados.get_nowait()  # ¿ya hay algo en el buzón?
        except queue.Empty:
            win.after(150, revisar_respuesta)      # todavía no: vuelve a revisar en 150 ms
            return

        campo_respuesta.delete("1.0", "end")       # borra la caja (línea 1, columna 0, hasta el final)
        campo_respuesta.insert("end", texto)       # SALIDA: muestra la respuesta (en vez de print)
        estado.config(text="Consulta terminada" if tipo == "ok" else "Ocurrió un error")
        boton.config(state="normal")               # vuelve a activar el botón

    def enviar():
        # ENTRADA: lee lo que escribió el usuario (en vez de input)
        api_key = campo_clave.get().strip()
        pregunta = campo_pregunta.get("1.0", "end").strip()
        if not api_key or not pregunta:            # validación: ¿falta algo?
            estado.config(text="Escribe tu API Key y una pregunta.")
            return

        boton.config(state="disabled")             # evita mandar muchas preguntas seguidas
        estado.config(text="Consultando a la IA...")
        campo_respuesta.delete("1.0", "end")
        # Manda al "ayudante" (hilo) a hacer la consulta y empieza a revisar el buzón
        threading.Thread(target=consultar, args=(api_key, pregunta), daemon=True).start()
        revisar_respuesta()

    # EVENTO: al presionar el botón se ejecuta enviar (sin paréntesis)
    boton = ttk.Button(frm, text="Preguntar a la IA", command=enviar)
    boton.pack(pady=8)