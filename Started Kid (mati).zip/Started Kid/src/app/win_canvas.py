"""Ventana 'Clima en La Piedad': datos de la API de Open-Meteo y 3 gráficas (LlegaBien)."""
import tkinter as tk
from tkinter import messagebox
import requests
from matplotlib.figure import Figure      # la figura sola, sin ventanas extra de pyplot
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
 
# ---------- Paleta de LlegaBien ----------
VERDE = "#01847D"
VERDE_CLARO = "#E2F2EF"
BLANCO = "#FFFFFF"
GRIS_FONDO = "#F0F3F2"
GRIS_OSCURO = "#2B3332"
GRIS = "#56605E"
FUENTE = "Segoe UI"
 
# ---------- Ciudad: La Piedad, Michoacán ----------
CIUDAD = "La Piedad, Michoacán"
LATITUD = 20.35
LONGITUD = -102.03
 
 
def obtener_clima():
    """Pide a la API de Open-Meteo la temperatura por hora de ayer y hoy (48 horas).
    Regresa dos listas: horas (texto "HH:MM") y temperaturas (°C).
    Si algo falla, muestra un mensaje y regresa dos listas vacías."""
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={LATITUD}&longitude={LONGITUD}"
        "&hourly=temperature_2m"     # dato que pedimos: temperatura a 2 m del suelo
        "&past_days=1"               # incluye el día de ayer
        "&forecast_days=1"           # y solo el día de hoy (sin esto llegan 7 días)
        "&timezone=auto"             # horas en el horario local de la ciudad
    )
    try:
        respuesta = requests.get(url, timeout=15)   # espera máximo 15 segundos
        respuesta.raise_for_status()                # si el servidor falla, lanza un error
        datos = respuesta.json()                    # convierte el texto JSON en diccionario
 
        fechas_completas = datos["hourly"]["time"]          # ej. "2026-11-12T13:00"
        temperaturas = datos["hourly"]["temperature_2m"]
    except requests.RequestException as error:      # sin internet, tiempo agotado, etc.
        messagebox.showerror("Sin conexión", f"No se pudo conectar con la API:\n{error}")
        return [], []
    except KeyError as error:                       # el JSON no trae la llave esperada
        messagebox.showerror("Datos incompletos", f"La API no regresó el dato:\n{error}")
        return [], []
 
    # Recortamos cada fecha para dejar solo la hora: "2026-11-12T13:00" -> "13:00"
    horas = []
    for fecha in fechas_completas:
        horas.append(fecha[11:16])
    return horas, temperaturas
 
 
def dar_formato(ax, horas, titulo):
    """Formato común de las 3 gráficas: título, ejes, rejilla y etiquetas legibles."""
    posiciones = list(range(len(horas)))             # 0, 1, 2, ... una posición por hora
    ax.set_title(titulo, fontsize=11)
    ax.set_xlabel("Hora (ayer y hoy)")
    ax.set_ylabel("Temperatura (°C)")
    ax.set_xticks(posiciones[::3])                   # una etiqueta cada 3 horas
    ax.set_xticklabels(horas[::3])
    ax.tick_params(axis="x", rotation=45, labelsize=8)
    ax.grid(True, linestyle="--", alpha=0.5)         # rejilla punteada
    if len(horas) > 24:
        ax.axvline(23.5, color=GRIS, linestyle=":")  # línea que separa ayer de hoy
 
 
def crear_grafica_linea(horas, temperaturas):
    """Gráfica de línea: muestra cómo sube y baja la temperatura."""
    posiciones = list(range(len(horas)))
    fig = Figure(figsize=(8, 2.4))                   # 8 x 2.4 pulgadas
    ax = fig.add_subplot()                           # el área donde se dibuja
    ax.plot(posiciones, temperaturas, color=VERDE, marker="o", markersize=3, linewidth=2)
    dar_formato(ax, horas, f"Temperatura en {CIUDAD} (línea)")
    fig.tight_layout()
    return fig
 
 
def crear_grafica_barras(horas, temperaturas):
    """Gráfica de barras: compara la temperatura de cada hora."""
    posiciones = list(range(len(horas)))
    fig = Figure(figsize=(8, 2.4))                   # 8 x 2.4 pulgadas
    ax = fig.add_subplot()                           # el área donde se dibuja
    ax.bar(posiciones, temperaturas, color=VERDE, alpha=0.8)
    dar_formato(ax, horas, f"Temperatura en {CIUDAD} (barras)")
    fig.tight_layout()
    return fig
 
 
def crear_grafica_dispersion(horas, temperaturas):
    """Gráfica de dispersión: cada hora es un punto suelto."""
    posiciones = list(range(len(horas)))
    fig = Figure(figsize=(8, 2.4))                   # 8 x 2.4 pulgadas
    ax = fig.add_subplot()                           # el área donde se dibuja
    ax.scatter(posiciones, temperaturas, color=VERDE, s=18, alpha=0.7)
    dar_formato(ax, horas, f"Temperatura en {CIUDAD} (dispersión)")
    fig.tight_layout()
    return fig
 
 
def mostrar_graficas(contenedor, horas, temperaturas):
    """Crea las 3 gráficas y las mete en la ventana, una debajo de otra."""
    figuras = [
        crear_grafica_linea(horas, temperaturas),
        crear_grafica_barras(horas, temperaturas),
        crear_grafica_dispersion(horas, temperaturas),
    ]
    for figura in figuras:
        lienzo = FigureCanvasTkAgg(figura, master=contenedor)   # "lienzo" de Tkinter para la gráfica
        lienzo.draw()
        lienzo.get_tk_widget().pack(pady=6, fill="x")
 
 
def open_win_canvas(parent: tk.Tk):
    """Abre la ventana del clima. (No cambiar el nombre: main.py la importa así)."""
    win = tk.Toplevel(parent)
    win.title(f"LlegaBien — Clima en {CIUDAD}")
    win.configure(bg=GRIS_FONDO)
 
    contenido = tk.Frame(win, bg=GRIS_FONDO, padx=20, pady=16)
    contenido.pack(fill="both", expand=True)
 
    # Encabezado
    tk.Label(contenido, text=f"Clima en {CIUDAD}", bg=GRIS_FONDO, fg=GRIS_OSCURO,
             font=(FUENTE, 18, "bold")).pack(anchor="w")
    tk.Label(contenido, text="Temperatura por hora de ayer y hoy · Fuente: API de Open-Meteo",
             bg=GRIS_FONDO, fg=GRIS, font=(FUENTE, 10)).pack(anchor="w", pady=(0, 10))
 
    # Fila con el botón y un mensaje de estado
    fila = tk.Frame(contenido, bg=GRIS_FONDO)
    fila.pack(fill="x")
    estado = tk.Label(fila, text="Presiona el botón para descargar los datos.",
                      bg=GRIS_FONDO, fg=GRIS, font=(FUENTE, 10))
 
    # Aquí se dibujan las gráficas
    zona_graficas = tk.Frame(contenido, bg=GRIS_FONDO)
    zona_graficas.pack(fill="both", expand=True, pady=(8, 0))
 
    def cargar():
        """Descarga los datos y dibuja las gráficas (solo una vez)."""
        estado.config(text="Descargando datos...")
        win.update_idletasks()                       # refresca la ventana para que se vea el mensaje
        horas, temperaturas = obtener_clima()
        if horas and temperaturas:
            mostrar_graficas(zona_graficas, horas, temperaturas)
            boton.config(state="disabled")           # evita dibujar las gráficas dos veces
            estado.config(text=f"Listo: {len(horas)} horas cargadas.")
        else:
            estado.config(text="No se pudieron cargar los datos. Intenta de nuevo.")
 
    boton = tk.Button(fila, text="Cargar y mostrar gráficas", command=cargar,
                      bg=VERDE, fg=BLANCO, activebackground=VERDE_CLARO, activeforeground=GRIS_OSCURO,
                      font=(FUENTE, 10, "bold"), relief="flat", padx=14, pady=6, cursor="hand2")
    boton.pack(side="left")
    estado.pack(side="left", padx=12)
 
 
# Para probar esta ventana sola: python src/app/win_canvas.py
if __name__ == "__main__":
    raiz = tk.Tk()
    raiz.title("Prueba win_canvas")
    tk.Button(raiz, text="Abrir ventana del clima", command=lambda: open_win_canvas(raiz)).pack(padx=40, pady=20)
    raiz.mainloop()